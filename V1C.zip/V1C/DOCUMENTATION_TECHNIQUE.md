# Station météo : documentation technique (version V1C)

ESIGELEC 2A, module Instrumentation et Systèmes (S07_PSE2_IS), partie 3 : projet.
Plan conforme aux consignes : **1. Méthode de fonctionnement**, **2. Ce qui marche**, **3. Documentation logicielle**.

---

## 1. Méthode de fonctionnement

### 1.1 Rôle du programme

Le programme lit les capteurs de la station météo pédagogique par un boîtier NI USB-6009 (ou USB-6001).
Il affiche les mesures en direct, déclenche des alarmes, enregistre tout dans des fichiers CSV,
puis relit ces fichiers pour tracer l'évolution sur un jour, une semaine, un mois ou un an et calculer des statistiques.
Sans boîtier, il passe automatiquement en **simulation**, ce qui permet de développer et de faire la démonstration hors de la salle.

### 1.2 Branchements utilisés

| Capteur | Entrée du boîtier | Lecture dans le programme | Conversion |
|---|---|---|---|
| Température | AI6 (RSE) | tâche analogique | T (°C) = A x U + B (`config.TEMPERATURE_A/B`, à étalonner) |
| Girouette | AI3 (RSE) | même tâche analogique que AI6 | angle = U / 5 V x 360° + décalage |
| Anémomètre | PFI0, compteur CTR0 | comptage des fronts descendants, lu toutes les 1 s | v (km/h) = impulsions/s x 2,4 |
| Pluviomètre à bascule | P0.7 | ligne numérique scrutée toutes les 20 ms | volume = basculements x `ML_PAR_BASCULE` |
| N° de station | P1.0 à P1.3 | 4 lignes numériques | entier = somme des bits x 2^i |

Le boîtier USB-6009 n'a qu'un compteur (CTR0), déjà pris par l'anémomètre. Le pluviomètre est donc lu en **scrutation logicielle** :
le programme relit la ligne P0.7 toutes les 20 ms et compte un basculement à chaque passage au niveau actif.
Les impulsions du pluviomètre sont lentes (quelques par minute au plus), donc rien n'est perdu.
Un anti-rebond de 100 ms évite de compter deux fois le même basculement.

### 1.3 Architecture

Le code est découpé en modules indépendants. L'acquisition est **interchangeable** : `AcquisitionDAQ` (vrai boîtier)
et `AcquisitionSimulee` exposent exactement les mêmes méthodes, donc le reste du programme ne sait pas d'où viennent les mesures.

```
                 main.py  (choix : boîtier / simulation / auto)
                    |
                    v
   +------------------------------- ihm.py : MaFenetre (thread principal) ---------------------------+
   |  Tableau de bord | Temps réel | Historique | Statistiques | Réglages                             |
   +-----------^-------------------------|----------------------------|------------------------------+
               | queue.Queue             | Station.mettre_a_jour()     | Statistiques.calculer()
               | (mesures, erreurs)      v                             v
   ThreadAcquisition  ------------>  station.py              stats.py  <---- stockage.py (lecture CSV)
   (thread secondaire)               alarmes, pics,                         ^
        |                            hors saison, pluie                     | Stockage.ajouter()
        v                                                                   | (écriture CSV)
   acquisition.py : AcquisitionDAQ (nidaqmx)  ou  AcquisitionSimulee        +---- depuis MaFenetre
        |
   config.py (voies, conversions, seuils, saisons) : importé par tous les modules
```

### 1.4 Déroulement d'une mesure

1. **Thread d'acquisition** (`ThreadAcquisition.run`) : pendant 1 s, il scrute le pluviomètre toutes les 20 ms.
   À la fin de la seconde, il lit la girouette et la température (une seule lecture des 2 voies analogiques),
   le compteur de l'anémomètre (puis le remet à zéro), le numéro de station et le compteur de basculements.
   Il range le tout dans un objet `Mesure` et le dépose dans une `queue.Queue`.
2. **IHM** (`MaFenetre.rafraichir`, toutes les 500 ms grâce à `after`) : elle vide la queue.
   Pour chaque mesure, elle appelle `Station.mettre_a_jour()` (calculs), puis `Stockage.ajouter()` (enregistrement),
   puis met à jour l'affichage.
3. **Station** : met à jour les valeurs courantes, le contenu du pluviomètre, le temps hors limite de saison,
   détecte un éventuel pic de vent et vérifie les 4 alarmes. Elle renvoie la liste des événements nouveaux,
   affichés dans le journal.
4. **Stockage** : accumule les mesures et écrit toutes les 60 s une ligne moyennée par capteur dans le CSV du jour.
   Les pics de vent sont écrits immédiatement.

Pourquoi un thread et une queue ? tkinter et matplotlib ne supportent pas d'être manipulés depuis plusieurs threads.
Le thread d'acquisition ne touche donc jamais à l'interface : il ne fait que lire le matériel et déposer des messages.
L'interface reste fluide même pendant la seconde de comptage de l'anémomètre.

### 1.5 Calculs principaux

- **Direction en texte** : la rose est découpée en 16 secteurs de 22,5° (N, NNE, NE, ENE, E, ..., NO, NNO).
  Le secteur N couvre de 348,75° à 11,25°.
- **Alarmes** : 4 alarmes (température haute, température basse, pluviomètre haut, pluviomètre bas) dont les seuils
  se règlent dans l'onglet Réglages. Un message n'est ajouté au journal qu'au moment où l'alarme s'active
  (pas un message par seconde), mais l'affichage reste rouge tant que la condition dure.
- **Pic de vent** : un point est un pic s'il est strictement plus grand que le point précédent, au moins égal au suivant
  et au-dessus du seuil `seuil_pic` (10 km/h par défaut). Le test se fait sur l'avant-dernier point, dès que le suivant
  est connu (1 s de retard). Les pics sont marqués d'un triangle rouge sur le graphe et enregistrés (capteur `vent_pic`).
- **Temps hors limite de saison** : chaque mois est rattaché à une saison (`SAISON_PAR_MOIS`) qui a une plage de
  température normale (`LIMITES_SAISON`). En direct, la durée entre deux mesures est ajoutée au compteur si la mesure
  précédente était hors plage. Dans les statistiques, le même calcul est refait à partir des fichiers.
- **Moyenne des directions** : on moyenne les vecteurs (sinus, cosinus) et pas les angles,
  sinon la moyenne de 350° et 10° donnerait 180° au lieu de 0°.
- **Pluviomètre** : le thread fournit un compteur cumulé. `Station` en fait la différence d'une mesure à l'autre.
  Si le compteur diminue (boîtier reconnecté, compteur reparti de 0), la différence est ignorée.
  Le bouton « Vider le contenant » remet le contenu à zéro.

### 1.6 Enregistrement des données

Un fichier par jour : `donnees/AAAA-MM-JJ.csv`, séparateur `;` (s'ouvre directement dans Excel).

```
horodatage;station;capteur;valeur
2026-11-13 14:11:00;5;station;5.000
2026-11-13 14:11:00;5;temperature;20.166
2026-11-13 14:11:00;5;direction;319.763
2026-11-13 14:11:00;5;vent;8.160
2026-11-13 14:11:00;5;pluie_ml;2.000
2026-11-13 14:11:37;5;vent_pic;12.000
```

- `temperature`, `vent` : moyennes sur 60 s ; `direction` : moyenne vectorielle sur 60 s ;
  `pluie_ml` : eau tombée pendant les 60 s ; `vent_pic` : un pic, horodaté à la seconde ;
  `station` : numéro de station, écrit à chaque début de fichier et à chaque changement.
- Le numéro de station est présent sur **chaque** ligne, ce qui permet de filtrer par station dans l'historique et les statistiques.
- Taille : 5 lignes par minute, soit environ 230 ko par jour et 85 Mo par an.
  Les mesures ne sont pas écrites à chaque seconde pour limiter cette taille et garder une relecture rapide
  (la période se change dans `config.PERIODE_ENREGISTREMENT_S`).

### 1.7 Graphes d'évolution et statistiques

Pour une période (jour, semaine du lundi au dimanche, mois, année) et une date, le programme relit les fichiers
des jours concernés, puis regroupe les points en intervalles réguliers :

| Période | Intervalle | Température | Vent | Pluie |
|---|---|---|---|---|
| Jour | 1 h | moyenne + zone min/max + seuils | moyenne + pic max | somme (barres) |
| Semaine | 6 h | idem | idem | idem |
| Mois | 1 jour | idem | idem | idem |
| An | 7 jours | idem | idem | idem |

Les boutons ◀ et ▶ reculent ou avancent d'une période, et le champ date accepte n'importe quelle date
(c'est la fonction « changer de date d'affichage »). La liste « Station » permet de n'afficher qu'une station.

L'onglet Statistiques calcule sur la période choisie : température moyenne, min et max avec leur date, écart-type,
temps et pourcentage hors limite de saison, vent moyen, plus forte moyenne, rafale maximale avec sa date, nombre de pics,
vent dominant (secteur le plus fréquent), cumul de pluie, nombre de jours de pluie, jour le plus pluvieux.

### 1.8 Stabilité

- Si `nidaqmx` n'est pas installé ou si le boîtier est absent au démarrage, le programme passe en simulation (mode auto)
  et l'indique dans la barre du haut et dans le journal.
- Si le boîtier est débranché en cours de route, le thread d'acquisition attrape l'erreur, ferme les tâches,
  signale « Boîtier déconnecté, reconnexion... » et retente d'ouvrir toutes les 5 s. Il ne s'arrête jamais sur une erreur.
- Une ligne de CSV abîmée est ignorée à la relecture, et une erreur d'écriture est affichée dans le journal sans arrêter le programme.
- À la fermeture de la fenêtre : arrêt du thread, fermeture des tâches nidaqmx, écriture des dernières mesures en attente.

### 1.9 Utilisation (pour le stagiaire)

1. Lancer `python main.py`. La barre du haut indique la source (boîtier ou simulation), le numéro de station et ses 4 LED.
2. **Tableau de bord** : valeurs en grand, état des alarmes (vert = normal, rouge = alarme), boussole, journal des événements.
3. **Temps réel** : les 5 dernières minutes des 4 grandeurs, avec les seuils en pointillés et les pics de vent.
4. **Historique** : choisir la période, la date, la station et le capteur.
5. **Statistiques** : mêmes choix, tableau de résultats.
6. **Réglages** : modifier les seuils d'alarme et le seuil de détection des pics, puis « Appliquer ».

---

## 2. Ce qui marche

Légende : **OK** = fonctionne et vérifié en simulation (tests automatiques et lancement de l'interface) ;
**À vérifier en salle** = le code existe mais n'a pas pu être essayé sur le boîtier réel.

### 2.1 Consignes du sujet

| Capteur | Consigne | Niveau | État | Où |
|---|---|---|---|---|
| Température | Afficher la température | vert | OK | Tableau de bord |
| | Alarme si supérieure à une valeur | vert | OK | Tableau de bord, journal |
| | Alarme si inférieure à une valeur | vert | OK | Tableau de bord, journal |
| | Calculer le temps hors limite de saison | vert | OK | Tableau de bord (direct), Statistiques (sur période) |
| | Enregistrer les températures | jaune | OK | CSV, capteur `temperature` |
| | Graphe temps réel avec limites visibles | jaune | OK | Temps réel |
| | Graphe jour / semaine / mois / an | orange | OK | Historique |
| | Changer de date d'affichage | rouge | OK | Historique (◀ ▶, date) |
| Girouette | Afficher la valeur | vert | OK | Tableau de bord (degrés) |
| | Graphe temps réel | vert | OK | Temps réel |
| | Direction en chaîne de caractères | jaune | OK | Tableau de bord (« Nord-Est (NE) ») |
| | Enregistrer les directions | jaune | OK | CSV, capteur `direction` |
| | Boussole | rouge | OK | Tableau de bord |
| Compteur (n° station) | Afficher en binaire (LED) | vert | OK | Barre du haut |
| | Afficher en numéro (int) | vert | OK | Barre du haut |
| | Enregistrer le numéro de station | jaune | OK | CSV, colonne `station` + capteur `station` |
| Anémomètre | Afficher la valeur | vert | OK | Tableau de bord |
| | Graphe temps réel | jaune | OK | Temps réel |
| | Afficher le pic sur le graphe | jaune | OK | Temps réel (triangles rouges + texte) |
| | Enregistrer les mesures | jaune | OK | CSV, capteur `vent` |
| | Enregistrer les pics | jaune | OK | CSV, capteur `vent_pic` |
| | Calculer un pic | rouge | OK | `Station.detecter_pic()` |
| Pluviomètre | Afficher la valeur du contenant | vert | OK | Tableau de bord (nombre de basculements) |
| | Afficher cette valeur en ml | vert | OK | Tableau de bord |
| | Alarme si valeur supérieure | jaune | OK | Tableau de bord, journal |
| | Alarme si valeur inférieure | jaune | OK | Tableau de bord, journal (désactivée tant que le seuil bas vaut 0) |
| | Graphe temps réel avec limites | jaune | OK | Temps réel |
| | Graphe jour / semaine / mois / an | orange | OK | Historique, capteur Pluie |
| | Changer de date d'affichage | rouge | OK | Historique |
| Statistiques | Statistiques météorologiques | rouge | OK | Onglet Statistiques |
| IHM | Ergonomie | orange | OK, à faire valider | 5 onglets, couleurs d'alarme, réglages sans toucher au code |
| Bonus | Stabilité | orange | OK en simulation | reconnexion automatique, voir 1.8 |

### 2.2 Vérifications effectuées

- **13 tests automatiques** (`python -m unittest test_station -v`), tous réussis : conversions, direction en texte,
  alarmes, pluviomètre (y compris la remise à zéro du compteur), détection de pic, temps hors limite de saison,
  bornes des périodes, agrégation, écriture et relecture CSV, statistiques.
- **Lancement de l'interface en simulation** avec 400 jours d'historique fictif : les 5 onglets s'affichent,
  la navigation ◀ ▶ et le filtre par station fonctionnent.
- **Temps de relecture** mesuré sur une année complète à une ligne par minute (85 Mo) : graphe d'un mois 0,2 s,
  graphe d'une année environ 6 s, statistiques d'une année environ 7 s. Pendant ce temps la fenêtre est figée
  (curseur d'attente). C'est la principale limite de la V1, voir section 4.
- **Test de panne** : une acquisition qui lève des erreurs à 3 lectures consécutives. Le thread signale l'erreur,
  se reconnecte et reprend les mesures sans s'arrêter.

Exemples de graphes produits (simulation) :

![Temps réel](images_doc/temps_reel.png)
![Historique semaine température](images_doc/historique_semaine_temperature.png)
![Historique mois vent](images_doc/historique_mois_vent.png)
![Historique année pluie](images_doc/historique_an_pluie.png)

### 2.3 Non vérifié, à faire en salle

- **Aucun essai sur le vrai boîtier** : `AcquisitionDAQ` suit le code du cours (voies RSE, `add_ci_count_edges_chan`,
  `add_di_chan` en `CHAN_PER_LINE`, recherche automatique du device), mais doit être testée en salle.
- **Logique des entrées numériques** : sur le 6009, entrées à 1 au repos (pull-up) ; sur le 6001, à 0 (pull-down).
  Régler `INVERSER_NUMERO_STATION` (si le numéro affiché est l'inverse de celui du codeur) et `NIVEAU_ACTIF_PLUVIOMETRE`
  (niveau lu quand l'auget bascule).
- **Étalonnage** : les lois tension -> °C et tension -> degrés de `config.py` sont des hypothèses linéaires.
  Il faut relever deux points de mesure pour la température et vérifier le Nord de la girouette.
- **À demander à l'enseignant** : volume d'eau par basculement (`ML_PAR_BASCULE`, 2 ml provisoirement)
  et limites de température par saison (`LIMITES_SAISON`, valeurs provisoires).

---

## 3. Documentation logicielle

Format demandé : pour chaque script, explication, exécutable ou non, imports ;
pour chaque classe, attributs (nom -> type) ; pour chaque méthode, explication, entrées (nom -> type), sorties (nom -> type).

### 3.1 main.py

- **Explication** : point d'entrée. Lit les options de la ligne de commande, crée éventuellement un historique fictif,
  ouvre l'acquisition (boîtier, simulation ou auto) puis lance la fenêtre.
- **Exécutable** : oui (`python main.py [--simu | --daq] [--demo JOURS]`).
- **Imports** : argparse, sys, acquisition (creer_acquisition), stockage (Stockage, generer_historique_demo), ihm (MaFenetre).
- **Fonction `main()`** : lance le programme. Entrées : aucune (lit `sys.argv`). Sorties : aucune.

### 3.2 config.py

- **Explication** : toutes les constantes réglables : noms des voies, conversions des capteurs, cadences,
  seuils par défaut, saisons et limites, dossier des données.
- **Exécutable** : non.
- **Imports** : aucun.
- Pas de classe. Constantes principales : `VOIE_TEMPERATURE -> str`, `VOIE_GIROUETTE -> str`,
  `COMPTEUR_ANEMOMETRE -> str`, `LIGNE_PLUVIOMETRE -> str`, `LIGNES_NUMERO_STATION -> str`,
  `INVERSER_NUMERO_STATION -> bool`, `NIVEAU_ACTIF_PLUVIOMETRE -> bool`, `KMH_PAR_IMPULSION_SECONDE -> float`,
  `TEMPERATURE_A / TEMPERATURE_B -> float`, `GIROUETTE_U_MAX / GIROUETTE_DECALAGE_DEG -> float`,
  `ML_PAR_BASCULE -> float`, `PERIODE_ACQUISITION_S -> float`, `PERIODE_ENREGISTREMENT_S -> int`,
  `POINTS_TEMPS_REEL -> int`, `TEMPERATURE_MIN / TEMPERATURE_MAX / PLUIE_MIN_ML / PLUIE_MAX_ML / SEUIL_PIC_VENT_KMH -> float`,
  `SAISON_PAR_MOIS -> dict[int, str]`, `LIMITES_SAISON -> dict[str, tuple[float, float]]`, `DOSSIER_DONNEES -> str`.

### 3.3 acquisition.py

- **Explication** : lecture des capteurs, sur le vrai boîtier ou en simulation, et thread d'acquisition cadencé.
- **Exécutable** : non.
- **Imports** : math, random, threading, time, dataclasses, datetime, config ; nidaqmx (importé seulement dans
  `AcquisitionDAQ`, donc le programme démarre même si la librairie est absente).

**Fonctions**

| Fonction | Explication | Entrées | Sorties |
|---|---|---|---|
| `tension_vers_temperature(u)` | loi linéaire de config | u -> float (V) | float (°C) |
| `tension_vers_direction(u)` | loi linéaire, ramenée dans [0, 360[ | u -> float (V) | float (°) |
| `bits_vers_entier(bits)` | [b0, b1, b2, b3] -> entier | bits -> list[bool] | int |
| `creer_acquisition(mode)` | crée et ouvre l'acquisition ; en "auto", bascule en simulation si le boîtier est absent | mode -> str ("auto", "daq", "simu") | (acquisition -> AcquisitionDAQ ou AcquisitionSimulee, message -> str) |

**Classe `Mesure`** (dataclass) : une mesure complète.
Attributs : `horodatage -> datetime`, `station -> int`, `temperature -> float`, `direction_deg -> float`,
`vent_kmh -> float`, `bascules -> int` (cumul depuis l'ouverture).

**Classe `AcquisitionDAQ`** : acquisition réelle avec nidaqmx.

Attributs : `nom_device -> str`, `task_ai -> nidaqmx.Task` (AI3 + AI6), `task_anemo -> nidaqmx.Task` (CTR0),
`task_pluvio -> nidaqmx.Task` (P0.7), `task_station -> nidaqmx.Task` (P1.0:3), `bascules -> int`,
`_etat_pluvio -> bool`, `_t_derniere_bascule -> float`, `_t_lecture_anemo -> float`, `_derniere_ai -> tuple[float, float]`.

| Méthode | Explication | Entrées | Sorties |
|---|---|---|---|
| `trouver_device()` | cherche un USB-600x (code du cours) | aucune | nom -> str (lève DaqError si rien) |
| `ouvrir()` | crée et configure les 4 tâches, démarre le compteur | aucune | aucune (lève une exception si échec) |
| `scruter_pluviometre()` | lit P0.7, compte un basculement sur front vers le niveau actif, anti-rebond | aucune | aucune |
| `lire_girouette()` | lit AI3 et AI6 en une fois, convertit AI3 | aucune | direction -> float (°) |
| `lire_temperature()` | convertit la tension AI6 lue juste avant | aucune | temperature -> float (°C) |
| `lire_anemometre()` | lit le compteur, le remet à zéro, divise par la durée réelle écoulée | aucune | vitesse -> float (km/h) |
| `lire_pluviometre()` | compteur cumulé | aucune | bascules -> int |
| `lire_numero_station()` | lit les 4 bits de P1, inversion éventuelle | aucune | numero -> int (0 à 15) |
| `fermer()` | ferme toutes les tâches sans lever d'erreur | aucune | aucune |
| `description()` | texte pour l'IHM | aucune | str |

**Classe `AcquisitionSimulee`** : mêmes méthodes que `AcquisitionDAQ`, valeurs générées.
Attributs : `numero_station -> int`, `bascules -> int`, `_rng -> random.Random`, `_direction -> float`,
`_vent -> float`, `_t0 -> float`, `_prochaine_bascule -> float`.
Température : cycle journalier + oscillation de quelques minutes + bruit ; direction : marche aléatoire ;
vent : base variable, bruit et rafales (5 % des secondes), arrondi à un nombre entier d'impulsions comme le vrai capteur ;
pluie : un basculement toutes les 5 à 20 s.

**Classe `ThreadAcquisition`** (hérite de `threading.Thread`) : boucle cadencée.

Attributs : `acquisition -> AcquisitionDAQ ou AcquisitionSimulee`, `file -> queue.Queue`, `_arret -> threading.Event`.

| Méthode | Explication | Entrées | Sorties |
|---|---|---|---|
| `run()` | toutes les 1 s : scrutation du pluviomètre, lecture de tous les capteurs, dépôt de `("mesure", Mesure)` dans la queue ; en cas d'erreur, dépôt de `("erreur", str)` puis reconnexion toutes les 5 s et `("info", str)` quand c'est reconnecté | aucune | aucune |
| `arreter()` | demande l'arrêt | aucune | aucune |

### 3.4 station.py

- **Explication** : toute la logique de calcul en temps réel, sans interface ni matériel (testable seule).
- **Exécutable** : non.
- **Imports** : collections (deque), datetime, config.

**Fonctions**

| Fonction | Explication | Entrées | Sorties |
|---|---|---|---|
| `direction_texte(deg)` | point cardinal sur 16 secteurs | deg -> float | str ("NNE") |
| `direction_texte_long(deg)` | idem en toutes lettres quand possible | deg -> float | str ("Nord-Est") |
| `saison(date)` | nom de la saison | date -> datetime | str |
| `limites_saison(date)` | plage normale de la saison | date -> datetime | (min, max) -> tuple[float, float] |

**Classe `Station`**

Attributs :
`numero -> int`, `temperature -> float`, `direction_deg -> float`, `direction_txt -> str`, `vent_kmh -> float`,
`vent_max_kmh -> float`, `derniere_mesure -> datetime`, `bascules_contenant -> int`, `nouvelles_bascules -> int`,
`temp_min / temp_max / pluie_min / pluie_max / seuil_pic -> float`, `alarmes -> dict[str, bool]`
(clés temp_haute, temp_basse, pluie_haute, pluie_basse), `temps_hors_saison_s -> float`, `hors_saison -> bool`,
`h_temps -> deque[datetime]`, `h_temperature / h_direction / h_vent / h_pluie_ml -> deque[float]`,
`pics -> deque[tuple[datetime, float]]`, `nouveau_pic -> tuple[datetime, float] ou None`.
Propriétés calculées : `volume_ml -> float`, `bits_station -> list[bool]` (b3 à b0).

| Méthode | Explication | Entrées | Sorties |
|---|---|---|---|
| `mettre_a_jour(mesure)` | intègre une mesure : valeurs, pluie, temps hors saison, historique, pic, alarmes | mesure -> Mesure | evenements -> list[str] |
| `detecter_pic()` | maximum local au-dessus du seuil sur l'avant-dernier point | aucune | (horodatage, vitesse) -> tuple[datetime, float] ou None |
| `verifier_alarmes()` | recalcule les 4 alarmes | aucune | messages des alarmes nouvellement actives -> list[str] |
| `vider_pluviometre()` | remet le contenu à zéro | aucune | aucune |
| `regler_seuils(temp_min, temp_max, pluie_min, pluie_max, seuil_pic)` | change les seuils | 5 x float | aucune (ValueError si min > max) |
| `texte_temps_hors_saison()` | durée formatée | aucune | str ("HH:MM:SS") |
| `saison_courante()` | saison de la dernière mesure | aucune | (nom -> str, min -> float, max -> float) |

### 3.5 stockage.py

- **Explication** : écriture des mesures moyennées dans les CSV journaliers, relecture pour les graphes et statistiques,
  génération d'un historique fictif pour la démonstration.
- **Exécutable** : non.
- **Imports** : csv, math, os, random, datetime, numpy, config.

**Fonctions**

| Fonction | Explication | Entrées | Sorties |
|---|---|---|---|
| `moyenne_angles(angles_deg)` | moyenne vectorielle | angles_deg -> list[float] | float (°) |
| `generer_historique_demo(stockage, jours, station, pas_min)` | crée des fichiers fictifs (sans toucher aux fichiers existants) | stockage -> Stockage, jours -> int, station -> int, pas_min -> int | aucune |

**Classe `Stockage`**

Attributs : `dossier -> str`, `erreur -> str ou None`, `_debut_bloc -> datetime`, `_temperatures / _directions / _vents -> list[float]`,
`_bascules -> int`, `_station -> int`, `_derniere_station -> int`.

| Méthode | Explication | Entrées | Sorties |
|---|---|---|---|
| `chemin_jour(jour)` | chemin du fichier d'un jour | jour -> date | str |
| `ecrire_lignes(lignes)` | ajoute des lignes dans les fichiers concernés (crée l'en-tête si besoin) | lignes -> list[[datetime, int, str, float]] | aucune (erreur rangée dans `erreur`) |
| `ajouter(mesure, nouvelles_bascules)` | accumule ; écrit les moyennes toutes les 60 s ou au changement de station | mesure -> Mesure, nouvelles_bascules -> int | aucune |
| `ajouter_pic(horodatage, vitesse, station)` | écrit un pic immédiatement | datetime, float, int | aucune |
| `vider_tampon()` | écrit l'intervalle en cours | aucune | aucune |
| `fermer()` | idem, à la fermeture | aucune | aucune |
| `lire(debut, fin, station)` | relit les mesures entre deux dates | debut -> datetime, fin -> datetime, station -> int ou None | dict[str, (np.ndarray, np.ndarray)] (timestamps, valeurs) |
| `stations_disponibles()` | numéros présents dans les 31 derniers fichiers | aucune | list[int] |

### 3.6 stats.py

- **Explication** : périodes (jour, semaine, mois, an), agrégation des séries, statistiques et séries des graphes d'évolution.
- **Exécutable** : non.
- **Imports** : datetime, numpy, config, station (direction_texte, limites_saison).

**Fonctions**

| Fonction | Explication | Entrées | Sorties |
|---|---|---|---|
| `bornes_periode(periode, date)` | début inclus et fin exclue de la période qui contient la date | periode -> str, date -> datetime | (datetime, datetime) |
| `decaler_date(periode, date, sens)` | avance ou recule d'une période | periode -> str, date -> datetime, sens -> int (+1 / -1) | datetime |
| `agreger(temps, valeurs, debut, fin, pas, mode)` | regroupe en intervalles réguliers | np.ndarray, np.ndarray, datetime, datetime, int (s), str ("moyenne", "min", "max", "somme") | (centres -> list[datetime], resultat -> np.ndarray) |
| `duree_des_points(temps, plafond)` | durée représentée par chaque point (écart au suivant, plafonné à 15 min) | temps -> np.ndarray, plafond -> float | np.ndarray |

**Classe `Statistiques`**

Attribut : `stockage -> Stockage`.

| Méthode | Explication | Entrées | Sorties |
|---|---|---|---|
| `calculer(periode, date, station)` | statistiques de la période (voir 1.7) | periode -> str, date -> datetime, station -> int ou None | dict[str, float, int ou str] |
| `serie_evolution(capteur, periode, date, station)` | séries agrégées pour le graphe d'évolution | capteur -> str, periode -> str, date -> datetime, station -> int ou None | dict ("x", "moyenne", "min", "max", "somme" ou "points", "debut", "fin", "pas") |

### 3.7 ihm.py

- **Explication** : interface graphique. Ne contient aucun calcul météo : elle affiche ce que calculent `Station` et `Statistiques`.
- **Exécutable** : non (lancé par main.py).
- **Imports** : math, queue, tkinter (tk, ttk, messagebox), datetime, matplotlib (Figure, FigureCanvasTkAgg, dates, ticker),
  config, acquisition (ThreadAcquisition), station (Station, direction_texte_long), stockage (Stockage),
  stats (PERIODES, Statistiques, bornes_periode, decaler_date).
- **Fonction `formateur_date(periode)`** : formateur d'axe en français (lun, mar... / janv, févr...).
  Entrée : periode -> str. Sortie : matplotlib.ticker.FuncFormatter.

**Classe `Boussole`** (hérite de `tk.Canvas`) : attributs `taille -> int`, `c -> float` (centre), `r -> float` (rayon), `aiguille -> int` (identifiant canvas).
Méthode `afficher(deg)` : oriente l'aiguille ; entrée deg -> float ; sortie aucune.

**Classe `Leds`** (hérite de `tk.Canvas`) : attribut `leds -> list[int]`.
Méthode `afficher(bits)` : allume les LED (jaune = 1) ; entrée bits -> list[bool] ; sortie aucune.

**Classe `MaFenetre`** (hérite de `tk.Tk`)

Attributs principaux :
`acquisition -> AcquisitionDAQ ou AcquisitionSimulee`, `file -> queue.Queue`, `station -> Station`, `stockage -> Stockage`,
`statistiques -> Statistiques`, `thread -> ThreadAcquisition`, `onglets -> ttk.Notebook`, `boussole -> Boussole`, `leds -> Leds`,
`lbl_temp / lbl_vent / lbl_pluie / lbl_numero ... -> tk.Label ou ttk.Label`, `liste_journal -> tk.Listbox`,
`fig_tr -> Figure` et `canvas_tr -> FigureCanvasTkAgg` (temps réel), `fig_h -> Figure` et `canvas_h -> FigureCanvasTkAgg` (historique),
`arbre_stats -> ttk.Treeview`, `h_periode / h_date / h_station / h_capteur / s_periode / s_date / s_station -> tk.StringVar`,
`reglages -> dict[str, tk.StringVar]`.

| Méthode | Explication | Entrées | Sorties |
|---|---|---|---|
| `__init__(acquisition, message_source)` | construit les 5 onglets, démarre le thread et la boucle `after` | acquisition, message_source -> str | aucune |
| `rafraichir()` | toutes les 500 ms : vide la queue, traite mesures et erreurs, met à jour l'affichage | aucune | aucune |
| `traiter_mesure(mesure)` | Station.mettre_a_jour + enregistrement des mesures et des pics | mesure -> Mesure | aucune |
| `afficher_valeurs()` | met à jour le tableau de bord, la boussole et les LED | aucune | aucune |
| `afficher_temps_reel()` | redessine les 4 courbes temps réel (seulement si l'onglet est visible) | aucune | aucune |
| `afficher_historique()` | trace le graphe d'évolution choisi | aucune | aucune |
| `afficher_statistiques()` | remplit le tableau de statistiques | aucune | aucune |
| `_occupe(actif)` | curseur d'attente pendant les relectures longues | actif -> bool | aucune |
| `journal(texte)` | ajoute une ligne horodatée et colorée au journal | texte -> str | aucune |
| `click_vider()` | bouton « Vider le contenant » | aucune | aucune |
| `click_appliquer()` | bouton « Appliquer » des réglages (vérifie les valeurs) | aucune | aucune |
| `quitter()` | arrêt propre : thread, tâches DAQ, données en attente | aucune | aucune |

### 3.8 test_station.py

- **Explication** : 13 tests unitaires de la logique (conversions, station, périodes, stockage, statistiques), sans matériel ni interface.
- **Exécutable** : oui (`python -m unittest test_station -v`).
- **Imports** : unittest, tempfile, datetime, numpy, acquisition, station, stats, stockage.
- Classes `TestConversions`, `TestStation`, `TestPeriodes`, `TestStockage` (héritent de `unittest.TestCase`) :
  chaque méthode `test_...` vérifie un comportement ; aucune entrée, aucune sortie (assertions).

---

## 4. Pistes pour la version finale

- Valider en salle et étalonner (section 2.3).
- Accélérer les vues « An » : enregistrer un résumé par jour (moyenne, min, max, cumul) dans un fichier à part,
  pour ne relire que 365 lignes au lieu de 2,6 millions, ou faire la relecture dans un thread.
- Exporter les statistiques en CSV, et ajouter une rose des vents (fréquence par secteur) dans les statistiques.
- Si les fichiers deviennent trop lourds sur plusieurs années, passer à `sqlite3` (inclus dans Python).
