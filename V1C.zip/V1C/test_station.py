"""
test_station.py : tests automatiques de la logique (sans matériel ni interface).

Script EXÉCUTABLE :  python -m unittest test_station -v
Imports : unittest, tempfile, datetime, numpy, config, acquisition, station, stockage, stats.
"""

import tempfile
import unittest
from datetime import datetime, timedelta

import numpy as np

import config
from acquisition import Mesure, bits_vers_entier, tension_vers_direction, tension_vers_temperature
from station import Station, direction_texte
from stats import Statistiques, agreger, bornes_periode, decaler_date
from stockage import Stockage, moyenne_angles


def mesure(t, temp=15.0, vent=5.0, direction=0.0, bascules=0, station=3):
    return Mesure(t, station, temp, direction, vent, bascules)


class TestConversions(unittest.TestCase):
    def test_direction_texte(self):
        self.assertEqual(direction_texte(0), "N")
        self.assertEqual(direction_texte(359), "N")
        self.assertEqual(direction_texte(22.5), "NNE")
        self.assertEqual(direction_texte(90), "E")
        self.assertEqual(direction_texte(225), "SO")
        self.assertEqual(direction_texte(292.5), "ONO")

    def test_bits(self):
        self.assertEqual(bits_vers_entier([True, False, True, False]), 5)
        self.assertEqual(bits_vers_entier([True, True, True, True]), 15)

    def test_tensions(self):
        self.assertAlmostEqual(tension_vers_direction(2.5), 180.0)
        self.assertAlmostEqual(tension_vers_temperature(0.0), -30.0)

    def test_moyenne_angles(self):
        self.assertAlmostEqual(moyenne_angles([350, 10]) % 360, 0.0, places=6)


class TestStation(unittest.TestCase):
    def setUp(self):
        self.s = Station()
        self.t0 = datetime(2026, 11, 13, 14, 0, 0)

    def test_alarmes_temperature(self):
        self.s.regler_seuils(0, 20, 0, 100, 10)
        ev = self.s.mettre_a_jour(mesure(self.t0, temp=25))
        self.assertTrue(self.s.alarmes["temp_haute"])
        self.assertEqual(len([e for e in ev if "haute" in e]), 1)
        ev = self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=1), temp=26))
        self.assertEqual(ev, [])                      # alarme déjà active : pas de nouveau message
        self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=2), temp=-3))
        self.assertTrue(self.s.alarmes["temp_basse"])
        self.assertFalse(self.s.alarmes["temp_haute"])

    def test_pluviometre(self):
        self.s.mettre_a_jour(mesure(self.t0, bascules=0))
        self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=1), bascules=3))
        self.assertEqual(self.s.bascules_contenant, 3)
        self.s.vider_pluviometre()
        self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=2), bascules=4))
        self.assertEqual(self.s.bascules_contenant, 1)
        # compteur remis à zéro (reconnexion) : pas de valeur négative
        self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=3), bascules=0))
        self.assertEqual(self.s.bascules_contenant, 1)

    def test_pic(self):
        self.s.seuil_pic = 10
        vents = [5, 8, 20, 9, 7, 9, 8]
        pics = []
        for i, v in enumerate(vents):
            self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=i), vent=v))
            if self.s.nouveau_pic:
                pics.append(self.s.nouveau_pic[1])
        self.assertEqual(pics, [20])                  # 9 est un max local mais sous le seuil

    def test_temps_hors_saison(self):
        # novembre = automne, limites par défaut 3 à 22 °C
        for i in range(11):
            self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=i), temp=30))
        self.assertAlmostEqual(self.s.temps_hors_saison_s, 10.0)
        self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=11), temp=15))
        self.s.mettre_a_jour(mesure(self.t0 + timedelta(seconds=12), temp=15))
        self.assertAlmostEqual(self.s.temps_hors_saison_s, 11.0)

    def test_bits_station(self):
        self.s.mettre_a_jour(mesure(self.t0, station=6))
        self.assertEqual(self.s.bits_station, [False, True, True, False])


class TestPeriodes(unittest.TestCase):
    def test_bornes(self):
        d = datetime(2026, 11, 13, 15, 30)       # vendredi
        self.assertEqual(bornes_periode("Jour", d), (datetime(2026, 11, 13), datetime(2026, 11, 14)))
        self.assertEqual(bornes_periode("Semaine", d), (datetime(2026, 11, 9), datetime(2026, 11, 16)))
        self.assertEqual(bornes_periode("Mois", datetime(2026, 12, 5)), (datetime(2026, 12, 1), datetime(2027, 1, 1)))
        self.assertEqual(bornes_periode("An", d), (datetime(2026, 1, 1), datetime(2027, 1, 1)))

    def test_decaler(self):
        self.assertEqual(decaler_date("Mois", datetime(2026, 1, 31), -1).month, 12)
        self.assertEqual(decaler_date("Semaine", datetime(2026, 11, 13), 1), datetime(2026, 11, 20))

    def test_agreger(self):
        debut = datetime(2026, 11, 13)
        t = np.array([debut.timestamp() + 10, debut.timestamp() + 20, debut.timestamp() + 3700])
        v = np.array([1.0, 3.0, 5.0])
        _, moy = agreger(t, v, debut, debut + timedelta(hours=3), 3600, "moyenne")
        self.assertEqual(moy[0], 2.0)
        self.assertEqual(moy[1], 5.0)
        self.assertTrue(np.isnan(moy[2]))
        _, som = agreger(t, v, debut, debut + timedelta(hours=3), 3600, "somme")
        self.assertEqual(list(som), [4.0, 5.0, 0.0])


class TestStockage(unittest.TestCase):
    def setUp(self):
        self._periode = config.PERIODE_ENREGISTREMENT_S
        config.PERIODE_ENREGISTREMENT_S = 10      # intervalles courts pour le test

    def tearDown(self):
        config.PERIODE_ENREGISTREMENT_S = self._periode

    def test_ecriture_relecture_stats(self):
        with tempfile.TemporaryDirectory() as dossier:
            st = Stockage(dossier)
            t0 = datetime(2026, 11, 13, 10, 0, 0)
            for i in range(25):           # 25 s -> 2 intervalles complets de 10 s + 1 en cours
                st.ajouter(mesure(t0 + timedelta(seconds=i), temp=10 + i, vent=4, direction=90), 1 if i == 5 else 0)
            st.ajouter_pic(t0 + timedelta(seconds=3), 30.0, 3)
            st.fermer()
            d = st.lire(t0, t0 + timedelta(hours=1), station=3)
            self.assertEqual(len(d["temperature"][1]), 3)
            self.assertAlmostEqual(d["temperature"][1][0], 15.0)    # moyenne de 10..20 (11 valeurs)
            self.assertAlmostEqual(float(np.sum(d["pluie_ml"][1])), 2.0)
            self.assertEqual(st.stations_disponibles(), [3])
            self.assertEqual(st.lire(t0, t0 + timedelta(hours=1), station=4), {})
            res = Statistiques(st).calculer("Jour", t0, 3)
            self.assertAlmostEqual(res["Rafale maximale (km/h)"], 30.0)
            self.assertEqual(res["Vent dominant"].split()[0], "E")


if __name__ == "__main__":
    unittest.main()
