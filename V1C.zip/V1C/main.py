"""
main.py : point d'entrée de la station météo.

Script EXÉCUTABLE :
    python main.py               -> boîtier NI si présent, sinon simulation (mode auto)
    python main.py --simu        -> simulation forcée (tests hors salle)
    python main.py --daq         -> boîtier NI obligatoire (erreur s'il est absent)
    python main.py --demo 400    -> crée d'abord 400 jours d'historique fictif (graphes jour/semaine/mois/an)

Imports : argparse, sys, acquisition (creer_acquisition), stockage (Stockage, generer_historique_demo), ihm (MaFenetre).
"""

import argparse
import sys

from acquisition import creer_acquisition
from stockage import Stockage, generer_historique_demo


def main():
    parser = argparse.ArgumentParser(description="Station météo ESIGELEC")
    groupe = parser.add_mutually_exclusive_group()
    groupe.add_argument("--simu", action="store_true", help="forcer l'acquisition simulée")
    groupe.add_argument("--daq", action="store_true", help="exiger le boîtier NI")
    parser.add_argument("--demo", type=int, metavar="JOURS", default=0,
                        help="générer JOURS jours d'historique fictif avant le lancement")
    args = parser.parse_args()

    if args.demo > 0:
        print(f"Génération de {args.demo} jours d'historique fictif...")
        generer_historique_demo(Stockage(), jours=args.demo)
        print("Terminé.")

    mode = "simu" if args.simu else ("daq" if args.daq else "auto")
    try:
        acquisition, message = creer_acquisition(mode)
    except Exception as e:
        print(f"Impossible d'ouvrir le boîtier NI : {e}")
        sys.exit(1)
    print(message)

    from ihm import MaFenetre      # import tardif : matplotlib/tkinter ne sont chargés qu'ici
    fenetre = MaFenetre(acquisition, message)
    fenetre.mainloop()


if __name__ == "__main__":
    main()
