# Station météo (V1C) - ESIGELEC, Instrumentation et Systèmes

Programme Python qui lit la station météo pédagogique (boîtier NI USB-6009 / USB-6001)
et affiche température, vent (vitesse, direction, boussole), pluie et numéro de station,
avec alarmes, graphes temps réel, historique jour / semaine / mois / an et statistiques.

## Lancer

```
python main.py            # boîtier NI s'il est branché, sinon simulation automatique
python main.py --simu     # simulation forcée (chez soi, sans boîtier)
python main.py --daq      # boîtier obligatoire (erreur s'il est absent)
python main.py --simu --demo 400   # crée 400 jours d'historique fictif puis lance (démo des graphes)
```

Tests automatiques (sans matériel) :

```
python -m unittest test_station -v
```

## Librairies

`nidaqmx` (seulement avec le boîtier), `numpy`, `matplotlib`, `tkinter` (fourni avec Python).
Testé avec Python 3.13, numpy 2.5, matplotlib 3.11, et écrit pour être compatible avec le Python 3.12 de la salle.

## Fichiers

| Fichier | Rôle |
|---|---|
| `main.py` | point d'entrée, choix de l'acquisition |
| `ihm.py` | interface tkinter (onglets, boussole, LED, graphes) |
| `station.py` | calculs : alarmes, pics, temps hors limite de saison, pluviomètre |
| `acquisition.py` | lecture du boîtier NI ou simulation, thread d'acquisition |
| `stockage.py` | enregistrement et relecture des CSV journaliers |
| `stats.py` | statistiques et graphes d'évolution |
| `config.py` | voies, conversions, seuils, saisons |
| `test_station.py` | tests unitaires |
| `DOCUMENTATION_TECHNIQUE.md` | fonctionnement détaillé et documentation de chaque script |

Les mesures sont enregistrées dans `donnees/AAAA-MM-JJ.csv` (créé au premier lancement).

## À faire en salle avant la recette

1. Vérifier le modèle du boîtier (6009 ou 6001) et régler `INVERSER_NUMERO_STATION` et `NIVEAU_ACTIF_PLUVIOMETRE` dans `config.py`.
2. Étalonner la température (`TEMPERATURE_A`, `TEMPERATURE_B`) et la girouette (`GIROUETTE_U_MAX`, `GIROUETTE_DECALAGE_DEG`).
3. Demander à l'enseignant le volume par basculement (`ML_PAR_BASCULE`) et les limites de saison (`LIMITES_SAISON`).
