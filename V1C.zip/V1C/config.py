"""
config.py : paramètres de la station météo.

Script NON exécutable : il ne contient que des constantes importées par les autres modules.
Imports : aucun.

Toutes les valeurs marquées « À ÉTALONNER » ou « À CONFIRMER » sont des hypothèses
de départ : elles doivent être vérifiées en salle ou auprès de l'enseignant.
"""

# ---------------------------------------------------------------------------
# Matériel NI (USB-6009 ou USB-6001)
# ---------------------------------------------------------------------------
NOM_DEVICE = ""                 # "" = recherche automatique d'un USB-600x, sinon ex. "Dev1"
VOIE_TEMPERATURE = "ai6"        # capteur de température
VOIE_GIROUETTE = "ai3"          # girouette
COMPTEUR_ANEMOMETRE = "ctr0"    # compteur utilisé pour l'anémomètre
TERMINAL_ANEMOMETRE = "pfi0"    # entrée des impulsions de l'anémomètre
LIGNE_PLUVIOMETRE = "port0/line7"   # contact du pluviomètre à bascule (P0.7)
LIGNES_NUMERO_STATION = "port1/line0:3"  # codeur 4 bits (port P1)

# Sur le 6009, les entrées numériques sont à 1 au repos (pull-up) ; sur le 6001 elles sont à 0 (pull-down).
# Mettre True si le numéro lu est l'inverse du numéro affiché sur le codeur (À VÉRIFIER EN SALLE).
INVERSER_NUMERO_STATION = False
# Niveau logique du contact pluviomètre quand l'auget bascule (False = contact vers GND, cas pull-up 6009).
NIVEAU_ACTIF_PLUVIOMETRE = False

# ---------------------------------------------------------------------------
# Conversions capteurs
# ---------------------------------------------------------------------------
# Anémomètre : 1 impulsion par tour ; vitesse (km/h) = impulsions par seconde x 2,4 (cours).
KMH_PAR_IMPULSION_SECONDE = 2.4

# Température : loi linéaire T(°C) = A x U(V) + B.  À ÉTALONNER (deux points de mesure suffisent).
TEMPERATURE_A = 20.0            # °C par volt
TEMPERATURE_B = -30.0           # °C à 0 V  (0 V -> -30 °C ; 5 V -> +70 °C)

# Girouette : loi linéaire 0 V -> 0° (Nord), GIROUETTE_U_MAX -> 360°.  À ÉTALONNER.
GIROUETTE_U_MAX = 5.0           # V
GIROUETTE_DECALAGE_DEG = 0.0    # correction si le zéro de la girouette n'est pas aligné sur le Nord

# Pluviomètre : volume d'eau par basculement de l'auget.  À CONFIRMER AVEC L'ENSEIGNANT.
ML_PAR_BASCULE = 2.0
ANTI_REBOND_PLUVIO_S = 0.1      # deux basculements séparés de moins de 100 ms = un seul

# ---------------------------------------------------------------------------
# Cadences
# ---------------------------------------------------------------------------
PERIODE_ACQUISITION_S = 1.0     # une mesure complète par seconde (durée de comptage de l'anémomètre)
PERIODE_SCRUTATION_S = 0.02     # scrutation du contact pluviomètre (impulsions lentes)
PERIODE_IHM_MS = 500            # rafraîchissement de l'interface
PERIODE_ENREGISTREMENT_S = 60   # une ligne moyennée par capteur toutes les 60 s dans le CSV (les pics sont écrits à la seconde)
POINTS_TEMPS_REEL = 300         # 300 points = 5 min de graphe temps réel à 1 mesure/s
DELAI_RECONNEXION_S = 5.0       # tentative de reconnexion au boîtier après une erreur

# ---------------------------------------------------------------------------
# Seuils d'alarme par défaut (modifiables dans l'IHM)
# ---------------------------------------------------------------------------
TEMPERATURE_MIN = 0.0           # °C
TEMPERATURE_MAX = 30.0          # °C
PLUIE_MIN_ML = 0.0              # ml dans le contenant (0 = alarme basse jamais déclenchée)
PLUIE_MAX_ML = 100.0            # ml dans le contenant
SEUIL_PIC_VENT_KMH = 10.0       # un maximum local de vent n'est retenu comme pic qu'au-dessus de ce seuil

# ---------------------------------------------------------------------------
# Saisons et limites de température associées (temps hors limite de saison).  À CONFIRMER.
# ---------------------------------------------------------------------------
SAISON_PAR_MOIS = {
    12: "Hiver", 1: "Hiver", 2: "Hiver",
    3: "Printemps", 4: "Printemps", 5: "Printemps",
    6: "Été", 7: "Été", 8: "Été",
    9: "Automne", 10: "Automne", 11: "Automne",
}
LIMITES_SAISON = {              # (min °C, max °C)
    "Hiver": (-5.0, 12.0),
    "Printemps": (3.0, 22.0),
    "Été": (12.0, 32.0),
    "Automne": (3.0, 22.0),
}

# ---------------------------------------------------------------------------
# Fichiers
# ---------------------------------------------------------------------------
DOSSIER_DONNEES = "donnees"     # relatif au dossier du programme ; un fichier CSV par jour
NUMERO_STATION_SIMULEE = 5      # numéro renvoyé par l'acquisition simulée
