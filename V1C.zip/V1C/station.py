"""
station.py : logique de calcul de la station (sans interface ni matériel).

Script NON exécutable seul (importé par ihm.py et les tests).
Imports : collections.deque, datetime, config.

Contenu :
- direction_texte(deg)       : conversion degrés -> "N", "NNE", ..., "NNO".
- saison(date)               : nom de la saison d'une date.
- Station                    : valeurs courantes, alarmes, pics de vent, temps hors limite de saison,
                               contenu du pluviomètre et historique temps réel pour les graphes.
"""

from collections import deque
from datetime import datetime

import config

ROSE_DES_VENTS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                  "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"]

NOMS_COMPLETS = {"N": "Nord", "E": "Est", "S": "Sud", "O": "Ouest",
                 "NE": "Nord-Est", "SE": "Sud-Est", "SO": "Sud-Ouest", "NO": "Nord-Ouest"}


def direction_texte(deg):
    """Convertit une direction en degrés en point cardinal sur 16 secteurs de 22,5°.
    Entrée : deg -> float ; sortie : str (ex. "NNE")."""
    return ROSE_DES_VENTS[int(((deg % 360) + 11.25) // 22.5) % 16]


def direction_texte_long(deg):
    """Comme direction_texte mais en toutes lettres quand c'est possible (ex. "Nord-Est")."""
    court = direction_texte(deg)
    return NOMS_COMPLETS.get(court, court)


def saison(date):
    """Retourne le nom de la saison (str) de la date (datetime) d'après config.SAISON_PAR_MOIS."""
    return config.SAISON_PAR_MOIS[date.month]


def limites_saison(date):
    """Retourne (min, max) en °C pour la saison de la date."""
    return config.LIMITES_SAISON[saison(date)]


class Station:
    """État courant de la station, recalculé à chaque nouvelle mesure."""

    def __init__(self, taille_historique=config.POINTS_TEMPS_REEL):
        # valeurs courantes
        self.numero = None              # int : numéro de station (0 à 15)
        self.temperature = None         # float : °C
        self.direction_deg = None       # float : degrés
        self.direction_txt = ""         # str : "N", "NNE", ...
        self.vent_kmh = None            # float : km/h
        self.vent_max_kmh = 0.0         # float : plus forte valeur depuis le lancement
        self.derniere_mesure = None     # datetime : horodatage de la dernière mesure

        # pluviomètre
        self.bascules_contenant = 0     # int : basculements depuis la dernière remise à zéro
        self._bascules_precedentes = None  # int : compteur cumulé reçu à la mesure précédente
        self.nouvelles_bascules = 0     # int : basculements apparus à la dernière mesure

        # seuils (modifiables par l'IHM)
        self.temp_min = config.TEMPERATURE_MIN      # float : °C
        self.temp_max = config.TEMPERATURE_MAX      # float : °C
        self.pluie_min = config.PLUIE_MIN_ML        # float : ml
        self.pluie_max = config.PLUIE_MAX_ML        # float : ml
        self.seuil_pic = config.SEUIL_PIC_VENT_KMH  # float : km/h

        # alarmes : nom -> bool (True = alarme active)
        self.alarmes = {"temp_haute": False, "temp_basse": False,
                        "pluie_haute": False, "pluie_basse": False}

        # temps hors limite de saison
        self.temps_hors_saison_s = 0.0  # float : secondes cumulées hors des limites de saison
        self.hors_saison = False        # bool : la dernière mesure est-elle hors limite ?

        # historique temps réel (pour les graphes), tailles bornées
        self.h_temps = deque(maxlen=taille_historique)       # datetime
        self.h_temperature = deque(maxlen=taille_historique) # float
        self.h_direction = deque(maxlen=taille_historique)   # float
        self.h_vent = deque(maxlen=taille_historique)        # float
        self.h_pluie_ml = deque(maxlen=taille_historique)    # float
        self.pics = deque(maxlen=taille_historique)          # (datetime, float) : pics détectés
        self.nouveau_pic = None         # (datetime, float) : pic détecté à la dernière mesure, sinon None

    # ------------------------------------------------------------------
    @property
    def volume_ml(self):
        """Contenu du pluviomètre en ml depuis la dernière remise à zéro."""
        return self.bascules_contenant * config.ML_PAR_BASCULE

    @property
    def bits_station(self):
        """Numéro de station en 4 bits, du poids fort au poids faible : [b3, b2, b1, b0]."""
        n = self.numero or 0
        return [bool(n >> i & 1) for i in (3, 2, 1, 0)]

    # ------------------------------------------------------------------
    def mettre_a_jour(self, mesure):
        """Intègre une nouvelle mesure.
        Entrée : mesure -> acquisition.Mesure
        Sortie : evenements -> list[str], messages à afficher (alarmes qui s'activent, pics, ...)."""
        evenements = []
        t = mesure.horodatage

        if self.numero is not None and mesure.station != self.numero:
            evenements.append(f"Numéro de station modifié : {self.numero} -> {mesure.station}")
        self.numero = mesure.station

        # temps hors limite de saison : la durée écoulée depuis la mesure précédente
        # est comptée si la mesure précédente était hors limite.
        if self.derniere_mesure is not None and self.hors_saison:
            dt = (t - self.derniere_mesure).total_seconds()
            if 0 < dt < 60:      # on ignore les trous (programme arrêté, boîtier débranché)
                self.temps_hors_saison_s += dt
        lo, hi = limites_saison(t)
        self.hors_saison = not (lo <= mesure.temperature <= hi)

        self.temperature = mesure.temperature
        self.direction_deg = mesure.direction_deg
        self.direction_txt = direction_texte(mesure.direction_deg)
        self.vent_kmh = mesure.vent_kmh
        self.vent_max_kmh = max(self.vent_max_kmh, mesure.vent_kmh)
        self.derniere_mesure = t

        # pluviomètre : on travaille sur la différence du compteur cumulé
        if self._bascules_precedentes is None or mesure.bascules < self._bascules_precedentes:
            delta = 0    # premier point, ou compteur remis à zéro (reconnexion du boîtier)
        else:
            delta = mesure.bascules - self._bascules_precedentes
        self._bascules_precedentes = mesure.bascules
        self.nouvelles_bascules = delta
        self.bascules_contenant += delta

        # historique temps réel
        self.h_temps.append(t)
        self.h_temperature.append(mesure.temperature)
        self.h_direction.append(mesure.direction_deg)
        self.h_vent.append(mesure.vent_kmh)
        self.h_pluie_ml.append(self.volume_ml)

        pic = self.detecter_pic()
        self.nouveau_pic = pic
        if pic is not None:
            self.pics.append(pic)
            evenements.append(f"Pic de vent : {pic[1]:.1f} km/h à {pic[0]:%H:%M:%S}")

        evenements += self.verifier_alarmes()
        return evenements

    def detecter_pic(self):
        """Détecte un pic de vent sur l'avant-dernier point : maximum local au-dessus du seuil.
        Sortie : (horodatage, vitesse) -> (datetime, float) ou None.
        Un plateau (deux valeurs égales) n'est compté qu'une fois, sur son premier point."""
        if len(self.h_vent) < 3:
            return None
        a, b, c = self.h_vent[-3], self.h_vent[-2], self.h_vent[-1]
        if b > a and b >= c and b >= self.seuil_pic:
            return (self.h_temps[-2], b)
        return None

    def verifier_alarmes(self):
        """Met à jour self.alarmes et retourne les messages des alarmes qui viennent de s'activer."""
        nouvelles = {
            "temp_haute": self.temperature > self.temp_max,
            "temp_basse": self.temperature < self.temp_min,
            "pluie_haute": self.volume_ml > self.pluie_max,
            "pluie_basse": self.volume_ml < self.pluie_min,
        }
        textes = {
            "temp_haute": f"Température haute : {self.temperature:.1f} °C > {self.temp_max:.1f} °C",
            "temp_basse": f"Température basse : {self.temperature:.1f} °C < {self.temp_min:.1f} °C",
            "pluie_haute": f"Pluviomètre plein : {self.volume_ml:.0f} ml > {self.pluie_max:.0f} ml",
            "pluie_basse": f"Pluie insuffisante : {self.volume_ml:.0f} ml < {self.pluie_min:.0f} ml",
        }
        messages = [textes[k] for k, actif in nouvelles.items() if actif and not self.alarmes[k]]
        self.alarmes = nouvelles
        return messages

    def vider_pluviometre(self):
        """Remet le contenu du pluviomètre à zéro (bouton « Vider » de l'IHM)."""
        self.bascules_contenant = 0

    def regler_seuils(self, temp_min, temp_max, pluie_min, pluie_max, seuil_pic):
        """Change les seuils d'alarme. Lève ValueError si min > max."""
        if temp_min > temp_max or pluie_min > pluie_max:
            raise ValueError("Le seuil bas doit être inférieur au seuil haut")
        self.temp_min, self.temp_max = float(temp_min), float(temp_max)
        self.pluie_min, self.pluie_max = float(pluie_min), float(pluie_max)
        self.seuil_pic = float(seuil_pic)
        if self.temperature is not None:
            self.verifier_alarmes()

    def texte_temps_hors_saison(self):
        """Temps hors limite formaté "HH:MM:SS"."""
        s = int(self.temps_hors_saison_s)
        return f"{s // 3600:02d}:{s // 60 % 60:02d}:{s % 60:02d}"

    def saison_courante(self):
        """(nom, min, max) de la saison de la dernière mesure (ou d'aujourd'hui)."""
        d = self.derniere_mesure or datetime.now()
        lo, hi = limites_saison(d)
        return saison(d), lo, hi
