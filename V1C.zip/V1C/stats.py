"""
stats.py : statistiques météorologiques et préparation des graphes d'évolution.

Script NON exécutable seul (importé par ihm.py).
Imports : datetime, numpy, config, station (direction_texte, limites_saison), stockage (Stockage).

Contenu :
- PERIODES, bornes_periode(), decaler_date() : gestion des périodes jour / semaine / mois / an.
- agreger()        : regroupe une série en intervalles réguliers (moyenne, min, max ou somme).
- Statistiques     : calcule les statistiques d'une période et les séries des graphes d'évolution.
"""

from datetime import datetime, timedelta

import numpy as np

import config
from station import direction_texte, limites_saison

PERIODES = ["Jour", "Semaine", "Mois", "An"]

# taille des intervalles d'agrégation des graphes d'évolution (secondes)
PAS_AGREGATION = {"Jour": 3600, "Semaine": 6 * 3600, "Mois": 86400, "An": 7 * 86400}


def bornes_periode(periode, date):
    """Début (inclus) et fin (exclue) de la période contenant la date.
    Entrées : periode -> str ("Jour", "Semaine", "Mois", "An"), date -> datetime
    Sortie  : (debut, fin) -> (datetime, datetime). La semaine va du lundi au dimanche."""
    j = datetime(date.year, date.month, date.day)
    if periode == "Jour":
        return j, j + timedelta(days=1)
    if periode == "Semaine":
        debut = j - timedelta(days=j.weekday())
        return debut, debut + timedelta(days=7)
    if periode == "Mois":
        debut = j.replace(day=1)
        fin = debut.replace(year=debut.year + 1, month=1) if debut.month == 12 else debut.replace(month=debut.month + 1)
        return debut, fin
    if periode == "An":
        return datetime(j.year, 1, 1), datetime(j.year + 1, 1, 1)
    raise ValueError(f"Période inconnue : {periode}")


def decaler_date(periode, date, sens):
    """Avance (sens = +1) ou recule (sens = -1) la date d'une période."""
    if periode == "Jour":
        return date + timedelta(days=sens)
    if periode == "Semaine":
        return date + timedelta(days=7 * sens)
    if periode == "Mois":
        m = date.month - 1 + sens
        annee, mois = date.year + m // 12, m % 12 + 1
        return date.replace(year=annee, month=mois, day=min(date.day, 28))
    return date.replace(year=date.year + sens, day=min(date.day, 28))


def agreger(temps, valeurs, debut, fin, pas, mode="moyenne"):
    """Regroupe une série en intervalles de `pas` secondes entre debut et fin.
    Entrées : temps -> np.ndarray (timestamps s), valeurs -> np.ndarray, debut/fin -> datetime,
              pas -> int (s), mode -> "moyenne" | "min" | "max" | "somme"
    Sortie  : (centres, resultat) -> (list[datetime], np.ndarray) ; NaN quand l'intervalle est vide
              (sauf en mode "somme" où il vaut 0)."""
    t0, t1 = debut.timestamp(), fin.timestamp()
    n = max(1, int(np.ceil((t1 - t0) / pas)))
    centres = [debut + timedelta(seconds=pas * (i + 0.5)) for i in range(n)]
    if len(temps) == 0:
        return centres, (np.zeros(n) if mode == "somme" else np.full(n, np.nan))
    idx = np.clip(((temps - t0) // pas).astype(int), 0, n - 1)
    if mode == "somme":
        return centres, np.bincount(idx, weights=valeurs, minlength=n)
    if mode == "moyenne":
        somme = np.bincount(idx, weights=valeurs, minlength=n)
        nb = np.bincount(idx, minlength=n)
        with np.errstate(invalid="ignore", divide="ignore"):
            return centres, np.where(nb > 0, somme / np.maximum(nb, 1), np.nan)
    resultat = np.full(n, np.nan)
    for i, v in zip(idx, valeurs):
        if np.isnan(resultat[i]) or (mode == "max" and v > resultat[i]) or (mode == "min" and v < resultat[i]):
            resultat[i] = v
    return centres, resultat


def duree_des_points(temps, plafond=900):
    """Durée (s) représentée par chaque point d'une série horodatée : écart au point suivant,
    plafonné ; le dernier point reçoit l'écart médian. Entrée/sortie : np.ndarray."""
    if len(temps) == 0:
        return np.array([])
    if len(temps) == 1:
        return np.array([float(config.PERIODE_ENREGISTREMENT_S)])
    ordre = np.argsort(temps)
    ecarts = np.diff(temps[ordre])
    ecarts = np.append(ecarts, np.median(ecarts))
    durees = np.empty_like(ecarts)
    durees[ordre] = np.minimum(ecarts, plafond)
    return durees


class Statistiques:
    """Calculs statistiques à partir des fichiers CSV."""

    def __init__(self, stockage):
        self.stockage = stockage    # stockage.Stockage : source des données

    def calculer(self, periode, date, station=None):
        """Statistiques d'une période.
        Entrées : periode -> str, date -> datetime, station -> int ou None
        Sortie  : dict nom -> valeur (float, str ou int), prêt à afficher. Les clés absentes
                  signifient « pas de données »."""
        debut, fin = bornes_periode(periode, date)
        d = self.stockage.lire(debut, fin, station)
        res = {"Période": f"{debut:%d/%m/%Y} au {(fin - timedelta(days=1)):%d/%m/%Y}"}

        if "temperature" in d and len(d["temperature"][1]):
            t, v = d["temperature"]
            res["Température moyenne (°C)"] = float(np.mean(v))
            res["Température minimale (°C)"] = float(np.min(v))
            res["Date du minimum"] = datetime.fromtimestamp(t[np.argmin(v)]).strftime("%d/%m %H:%M")
            res["Température maximale (°C)"] = float(np.max(v))
            res["Date du maximum"] = datetime.fromtimestamp(t[np.argmax(v)]).strftime("%d/%m %H:%M")
            res["Écart-type (°C)"] = float(np.std(v))
            # temps hors limite de saison : chaque point « dure » jusqu'au point suivant
            # (plafonné à 15 min pour ne pas compter les périodes où la station était arrêtée)
            durees = duree_des_points(t)
            hors = 0.0
            for ti, vi, di in zip(t, v, durees):
                lo, hi = limites_saison(datetime.fromtimestamp(ti))
                if not (lo <= vi <= hi):
                    hors += di
            res["Temps hors limite de saison (h)"] = hors / 3600
            res["Part du temps hors limite (%)"] = 100.0 * hors / max(float(np.sum(durees)), 1e-9)

        if "vent" in d and len(d["vent"][1]):
            v = d["vent"][1]
            res["Vent moyen (km/h)"] = float(np.mean(v))
            res["Vent moyen maximal (km/h)"] = float(np.max(v))
        if "vent_pic" in d and len(d["vent_pic"][1]):
            t, v = d["vent_pic"]
            res["Rafale maximale (km/h)"] = float(np.max(v))
            res["Date de la rafale maximale"] = datetime.fromtimestamp(t[np.argmax(v)]).strftime("%d/%m %H:%M")
            res["Nombre de pics enregistrés"] = int(len(v))
        if "direction" in d and len(d["direction"][1]):
            v = d["direction"][1]
            secteurs = [direction_texte(a) for a in v]
            dominant = max(set(secteurs), key=secteurs.count)
            res["Vent dominant"] = f"{dominant} ({100 * secteurs.count(dominant) / len(secteurs):.0f} % du temps)"

        if "pluie_ml" in d and len(d["pluie_ml"][1]):
            t, v = d["pluie_ml"]
            res["Cumul de pluie (ml)"] = float(np.sum(v))
            jours_pluie = {datetime.fromtimestamp(ti).date() for ti, vi in zip(t, v) if vi > 0}
            res["Jours de pluie"] = len(jours_pluie)
            _, par_jour = agreger(t, v, debut, fin, 86400, "somme")
            res["Jour le plus pluvieux (ml)"] = float(np.max(par_jour))

        if len(res) == 1:
            res["Aucune donnée"] = "pas d'enregistrement sur cette période"
        return res

    def serie_evolution(self, capteur, periode, date, station=None):
        """Séries agrégées pour le graphe d'évolution d'un capteur.
        Entrées : capteur -> str ("Température", "Vent", "Pluie", "Direction"), periode, date, station
        Sortie  : dict avec "x" -> list[datetime] et une ou plusieurs séries np.ndarray
                  ("moyenne", "min", "max" ou "somme"), plus "debut"/"fin" -> datetime et "pas" -> int."""
        debut, fin = bornes_periode(periode, date)
        pas = PAS_AGREGATION[periode]
        d = self.stockage.lire(debut, fin, station)
        vide = (np.array([]), np.array([]))
        out = {"debut": debut, "fin": fin, "pas": pas}
        if capteur == "Température":
            t, v = d.get("temperature", vide)
            out["x"], out["moyenne"] = agreger(t, v, debut, fin, pas, "moyenne")
            _, out["min"] = agreger(t, v, debut, fin, pas, "min")
            _, out["max"] = agreger(t, v, debut, fin, pas, "max")
        elif capteur == "Vent":
            t, v = d.get("vent", vide)
            out["x"], out["moyenne"] = agreger(t, v, debut, fin, pas, "moyenne")
            tp, vp = d.get("vent_pic", vide)
            _, out["max"] = agreger(tp, vp, debut, fin, pas, "max")
        elif capteur == "Pluie":
            t, v = d.get("pluie_ml", vide)
            out["x"], out["somme"] = agreger(t, v, debut, fin, pas, "somme")
        elif capteur == "Direction":
            t, v = d.get("direction", vide)
            out["x"] = [datetime.fromtimestamp(x) for x in t]
            out["points"] = v
        return out
