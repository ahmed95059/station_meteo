"""
ihm.py : interface graphique de la station météo (tkinter + matplotlib).

Script NON exécutable seul : il est lancé par main.py (qui choisit l'acquisition).
Imports : math, queue, datetime, tkinter (tk, ttk, messagebox), matplotlib (Figure, ticker,
          FigureCanvasTkAgg, dates), config, acquisition (ThreadAcquisition),
          station (Station, direction_texte_long), stockage (Stockage), stats (Statistiques, ...).

Contenu :
- Boussole   : Canvas tkinter qui dessine une rose des vents et une aiguille.
- Leds       : Canvas tkinter qui affiche 4 LED (numéro de station en binaire).
- MaFenetre  : fenêtre principale à onglets (Tableau de bord, Temps réel, Historique,
               Statistiques, Réglages).

Règle importante : tkinter et matplotlib ne sont manipulés QUE depuis le thread principal.
Le thread d'acquisition dépose ses mesures dans une queue.Queue, que MaFenetre vide
périodiquement grâce à tk.after().
"""

import math
import queue
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.dates as mdates
import matplotlib.ticker as mticker
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import config
from acquisition import ThreadAcquisition
from station import Station, direction_texte_long
from stats import PERIODES, Statistiques, bornes_periode, decaler_date
from stockage import Stockage

JOURS_FR = ["lun", "mar", "mer", "jeu", "ven", "sam", "dim"]
MOIS_FR = ["janv", "févr", "mars", "avr", "mai", "juin", "juil", "août", "sept", "oct", "nov", "déc"]


def formateur_date(periode):
    """Formateur d'axe matplotlib en français (indépendant de la langue de Windows)."""
    def f(x, _pos):
        d = mdates.num2date(x).replace(tzinfo=None)
        if periode == "Jour":
            return f"{d:%H:%M}"
        if periode == "Semaine":
            return f"{JOURS_FR[d.weekday()]} {d.day}"
        if periode == "Mois":
            return f"{d:%d/%m}"
        return MOIS_FR[d.month - 1]
    return mticker.FuncFormatter(f)


COULEUR_OK = "#2e7d32"
COULEUR_ALARME = "#c62828"
COULEUR_FOND = "#f4f6f8"
COULEUR_CARTE = "#ffffff"
POLICE_VALEUR = ("Segoe UI", 26, "bold")
POLICE_TITRE = ("Segoe UI", 11, "bold")
POLICE_TEXTE = ("Segoe UI", 10)


# ---------------------------------------------------------------------------
class Boussole(tk.Canvas):
    """Rose des vents avec une aiguille qui indique d'où vient le vent."""

    def __init__(self, parent, taille=220):
        super().__init__(parent, width=taille, height=taille, bg=COULEUR_CARTE, highlightthickness=0)
        self.taille = taille                   # int : côté du canvas (pixels)
        self.c = taille / 2                    # float : centre
        self.r = taille / 2 - 22               # float : rayon du cadran
        self.aiguille = None                   # int : identifiant de l'aiguille sur le canvas
        self._dessiner_cadran()

    def _dessiner_cadran(self):
        c, r = self.c, self.r
        self.create_oval(c - r, c - r, c + r, c + r, outline="#90a4ae", width=2)
        for i in range(16):
            a = math.radians(i * 22.5)
            l = 12 if i % 4 == 0 else (8 if i % 2 == 0 else 4)
            x1, y1 = c + (r - l) * math.sin(a), c - (r - l) * math.cos(a)
            x2, y2 = c + r * math.sin(a), c - r * math.cos(a)
            self.create_line(x1, y1, x2, y2, fill="#607d8b", width=2 if i % 4 == 0 else 1)
        for texte, a in (("N", 0), ("E", 90), ("S", 180), ("O", 270)):
            ra = math.radians(a)
            self.create_text(c + (r + 12) * math.sin(ra), c - (r + 12) * math.cos(ra),
                             text=texte, font=POLICE_TITRE, fill=COULEUR_ALARME if texte == "N" else "#37474f")
        self.create_oval(c - 5, c - 5, c + 5, c + 5, fill="#37474f", outline="")

    def afficher(self, deg):
        """Oriente l'aiguille vers deg (0° = Nord, sens horaire)."""
        if self.aiguille is not None:
            self.delete(self.aiguille)
        a = math.radians(deg)
        c, l = self.c, self.r - 16
        self.aiguille = self.create_line(c - 0.35 * l * math.sin(a), c + 0.35 * l * math.cos(a),
                                         c + l * math.sin(a), c - l * math.cos(a),
                                         arrow=tk.LAST, arrowshape=(16, 20, 7), width=4, fill=COULEUR_ALARME)


class Leds(tk.Canvas):
    """4 LED représentant les bits b3 b2 b1 b0 du numéro de station."""

    def __init__(self, parent, nb=4, diametre=18):
        super().__init__(parent, width=nb * (diametre + 8), height=diametre + 18,
                         bg=parent.cget("bg") if isinstance(parent, tk.Frame) else COULEUR_FOND,
                         highlightthickness=0)
        self.leds = []                         # list[int] : identifiants des cercles
        for i in range(nb):
            x = 4 + i * (diametre + 8)
            self.leds.append(self.create_oval(x, 2, x + diametre, 2 + diametre, fill="#555", outline="#222"))
            self.create_text(x + diametre / 2, diametre + 11, text=f"b{nb - 1 - i}", font=("Segoe UI", 7))

    def afficher(self, bits):
        """bits -> list[bool], du poids fort au poids faible."""
        for led, b in zip(self.leds, bits):
            self.itemconfigure(led, fill="#ffeb3b" if b else "#555")


# ---------------------------------------------------------------------------
class MaFenetre(tk.Tk):
    """Fenêtre principale de la station météo."""

    def __init__(self, acquisition, message_source=""):
        super().__init__()
        self.title("Station météo - ESIGELEC")
        self.geometry("1280x820")
        self.minsize(1050, 700)
        self.configure(bg=COULEUR_FOND)

        self.acquisition = acquisition              # AcquisitionDAQ | AcquisitionSimulee
        self.file = queue.Queue()                   # queue.Queue : messages du thread d'acquisition
        self.station = Station()                    # Station : calculs temps réel
        self.stockage = Stockage()                  # Stockage : fichiers CSV
        self.statistiques = Statistiques(self.stockage)  # Statistiques
        self.thread = ThreadAcquisition(acquisition, self.file)  # ThreadAcquisition
        self._en_erreur = False                     # bool : acquisition interrompue ?

        self._styles()
        self._barre_haute(message_source)
        self.onglets = ttk.Notebook(self)           # ttk.Notebook : les 5 onglets
        self.onglets.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self._onglet_tableau_de_bord()
        self._onglet_temps_reel()
        self._onglet_historique()
        self._onglet_statistiques()
        self._onglet_reglages()
        self.onglets.bind("<<NotebookTabChanged>>", self._changement_onglet)

        self.protocol("WM_DELETE_WINDOW", self.quitter)
        self.journal(message_source or "Démarrage")
        self.thread.start()
        self.after(config.PERIODE_IHM_MS, self.rafraichir)

    # ======================================================================= construction
    def _styles(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("TNotebook", background=COULEUR_FOND)
        st.configure("TNotebook.Tab", padding=(14, 6), font=POLICE_TITRE)
        st.configure("Carte.TLabelframe", background=COULEUR_CARTE)
        st.configure("Carte.TLabelframe.Label", font=POLICE_TITRE, background=COULEUR_CARTE)
        st.configure("Carte.TLabel", background=COULEUR_CARTE, font=POLICE_TEXTE)
        st.configure("Valeur.TLabel", background=COULEUR_CARTE, font=POLICE_VALEUR)
        st.configure("Haut.TLabel", background=COULEUR_FOND, font=POLICE_TEXTE)

    def _carte(self, parent, titre):
        f = ttk.LabelFrame(parent, text=titre, style="Carte.TLabelframe", padding=10)
        return f

    def _barre_haute(self, message_source):
        haut = tk.Frame(self, bg=COULEUR_FOND)
        haut.pack(fill="x", padx=10, pady=6)
        tk.Label(haut, text="Station météo", font=("Segoe UI", 18, "bold"), bg=COULEUR_FOND).pack(side="left")
        tk.Label(haut, text="   Station n°", font=POLICE_TITRE, bg=COULEUR_FOND).pack(side="left")
        self.lbl_numero = tk.Label(haut, text="--", font=("Segoe UI", 18, "bold"), fg="#1565c0", bg=COULEUR_FOND)
        self.lbl_numero.pack(side="left")
        self.leds = Leds(haut)
        self.leds.pack(side="left", padx=10)
        self.lbl_binaire = tk.Label(haut, text="0000", font=("Consolas", 12), bg=COULEUR_FOND)
        self.lbl_binaire.pack(side="left")
        self.lbl_heure = tk.Label(haut, text="", font=POLICE_TITRE, bg=COULEUR_FOND)
        self.lbl_heure.pack(side="right")
        self.lbl_source = tk.Label(haut, text=self.acquisition.description(), font=POLICE_TEXTE,
                                   bg=COULEUR_FOND, fg="#555")
        self.lbl_source.pack(side="right", padx=15)

    # -- onglet 1 -----------------------------------------------------------
    def _onglet_tableau_de_bord(self):
        page = tk.Frame(self.onglets, bg=COULEUR_FOND)
        self.onglets.add(page, text="Tableau de bord")
        for i in range(3):
            page.columnconfigure(i, weight=1, uniform="col")
        page.rowconfigure(1, weight=1)

        # Température
        c = self._carte(page, "Température")
        c.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.lbl_temp = ttk.Label(c, text="-- °C", style="Valeur.TLabel")
        self.lbl_temp.pack(anchor="w")
        self.lbl_temp_alarme = tk.Label(c, text="", font=POLICE_TITRE, bg=COULEUR_CARTE)
        self.lbl_temp_alarme.pack(anchor="w", pady=(2, 6))
        self.lbl_temp_seuils = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_temp_seuils.pack(anchor="w")
        self.lbl_saison = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_saison.pack(anchor="w")
        self.lbl_hors_saison = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_hors_saison.pack(anchor="w")

        # Vent
        c = self._carte(page, "Vent")
        c.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        self.lbl_vent = ttk.Label(c, text="-- km/h", style="Valeur.TLabel")
        self.lbl_vent.pack(anchor="w")
        self.lbl_vent_max = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_vent_max.pack(anchor="w", pady=(2, 6))
        self.lbl_direction = ttk.Label(c, text="Direction : --", style="Carte.TLabel", font=POLICE_TITRE)
        self.lbl_direction.pack(anchor="w")
        self.lbl_direction_deg = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_direction_deg.pack(anchor="w")

        # Boussole
        c = self._carte(page, "Boussole (d'où vient le vent)")
        c.grid(row=0, column=2, sticky="nsew", padx=6, pady=6)
        self.boussole = Boussole(c)
        self.boussole.pack()

        # Pluie
        c = self._carte(page, "Pluviomètre")
        c.grid(row=1, column=0, sticky="nsew", padx=6, pady=6)
        self.lbl_pluie = ttk.Label(c, text="-- ml", style="Valeur.TLabel")
        self.lbl_pluie.pack(anchor="w")
        self.lbl_bascules = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_bascules.pack(anchor="w")
        self.lbl_pluie_alarme = tk.Label(c, text="", font=POLICE_TITRE, bg=COULEUR_CARTE)
        self.lbl_pluie_alarme.pack(anchor="w", pady=(2, 6))
        self.lbl_pluie_seuils = ttk.Label(c, text="", style="Carte.TLabel")
        self.lbl_pluie_seuils.pack(anchor="w")
        ttk.Button(c, text="Vider le contenant", command=self.click_vider).pack(anchor="w", pady=8)

        # Journal des événements
        c = self._carte(page, "Journal (alarmes, pics, erreurs)")
        c.grid(row=1, column=1, columnspan=2, sticky="nsew", padx=6, pady=6)
        self.liste_journal = tk.Listbox(c, font=("Consolas", 10), height=12, activestyle="none")
        barre = ttk.Scrollbar(c, orient="vertical", command=self.liste_journal.yview)
        self.liste_journal.configure(yscrollcommand=barre.set)
        self.liste_journal.pack(side="left", fill="both", expand=True)
        barre.pack(side="right", fill="y")

    # -- onglet 2 -----------------------------------------------------------
    def _onglet_temps_reel(self):
        page = tk.Frame(self.onglets, bg=COULEUR_FOND)
        self.onglets.add(page, text="Temps réel")
        self.fig_tr = Figure(figsize=(10, 7), dpi=90)
        self.fig_tr.subplots_adjust(left=0.07, right=0.98, top=0.95, bottom=0.07, hspace=0.35)
        ax_t, ax_v, ax_d, ax_p = [self.fig_tr.add_subplot(4, 1, i + 1) for i in range(4)]
        self.ax_tr = (ax_t, ax_v, ax_d, ax_p)

        self.l_temp, = ax_t.plot([], [], color="#e65100", label="Température")
        self.l_tmax = ax_t.axhline(self.station.temp_max, color=COULEUR_ALARME, ls="--", label="Seuil haut")
        self.l_tmin = ax_t.axhline(self.station.temp_min, color="#1565c0", ls="--", label="Seuil bas")
        ax_t.set_ylabel("°C"); ax_t.set_title("Température", fontsize=10, loc="left")
        ax_t.legend(loc="upper left", fontsize=8, ncol=3)

        self.l_vent, = ax_v.plot([], [], color="#00838f", label="Vent")
        self.l_pics, = ax_v.plot([], [], "v", color=COULEUR_ALARME, ms=8, label="Pics")
        self.txt_pic = ax_v.text(0.99, 0.9, "", transform=ax_v.transAxes, ha="right", va="top", fontsize=9)
        ax_v.set_ylabel("km/h"); ax_v.set_title("Vitesse du vent", fontsize=10, loc="left")
        ax_v.legend(loc="upper left", fontsize=8, ncol=2)

        self.l_dir, = ax_d.plot([], [], ".", color="#6a1b9a", ms=4)
        ax_d.set_ylim(0, 360); ax_d.set_yticks([0, 90, 180, 270, 360])
        ax_d.set_yticklabels(["N", "E", "S", "O", "N"])
        ax_d.set_title("Direction du vent", fontsize=10, loc="left")

        self.l_pluie, = ax_p.plot([], [], color="#1565c0", drawstyle="steps-post", label="Contenu")
        self.l_pmax = ax_p.axhline(self.station.pluie_max, color=COULEUR_ALARME, ls="--", label="Seuil haut")
        self.l_pmin = ax_p.axhline(self.station.pluie_min, color="#1565c0", ls=":", label="Seuil bas")
        ax_p.set_ylabel("ml"); ax_p.set_title("Pluviomètre (contenu)", fontsize=10, loc="left")
        ax_p.legend(loc="upper left", fontsize=8, ncol=3)

        for ax in self.ax_tr:
            ax.grid(alpha=0.3)
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M:%S"))
        self.canvas_tr = FigureCanvasTkAgg(self.fig_tr, master=page)
        self.canvas_tr.get_tk_widget().pack(fill="both", expand=True)

    # -- onglet 3 -----------------------------------------------------------
    def _barre_periode(self, page, action):
        """Barre commune aux onglets Historique et Statistiques : période, date, station."""
        barre = tk.Frame(page, bg=COULEUR_FOND)
        barre.pack(fill="x", padx=6, pady=6)
        v_periode = tk.StringVar(value="Jour")
        v_date = tk.StringVar(value=datetime.now().strftime("%d/%m/%Y"))
        v_station = tk.StringVar(value="Toutes")
        tk.Label(barre, text="Période :", bg=COULEUR_FOND, font=POLICE_TEXTE).pack(side="left")
        cb = ttk.Combobox(barre, textvariable=v_periode, values=PERIODES, state="readonly", width=9)
        cb.pack(side="left", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda e: action())
        tk.Label(barre, text="   Date (jj/mm/aaaa) :", bg=COULEUR_FOND, font=POLICE_TEXTE).pack(side="left")
        ttk.Button(barre, text="◀", width=3, command=lambda: self._decaler(v_periode, v_date, -1, action)).pack(side="left")
        e = ttk.Entry(barre, textvariable=v_date, width=11, justify="center")
        e.pack(side="left", padx=2)
        e.bind("<Return>", lambda ev: action())
        ttk.Button(barre, text="▶", width=3, command=lambda: self._decaler(v_periode, v_date, +1, action)).pack(side="left")
        ttk.Button(barre, text="Aujourd'hui",
                   command=lambda: (v_date.set(datetime.now().strftime("%d/%m/%Y")), action())).pack(side="left", padx=6)
        tk.Label(barre, text="   Station :", bg=COULEUR_FOND, font=POLICE_TEXTE).pack(side="left")
        cb_st = ttk.Combobox(barre, textvariable=v_station, values=["Toutes"], state="readonly", width=8,
                             postcommand=lambda: cb_st.configure(
                                 values=["Toutes"] + [str(s) for s in self.stockage.stations_disponibles()]))
        cb_st.pack(side="left", padx=4)
        cb_st.bind("<<ComboboxSelected>>", lambda e: action())
        ttk.Button(barre, text="Afficher", command=action).pack(side="left", padx=10)
        return barre, v_periode, v_date, v_station

    def _lire_date(self, v_date):
        try:
            return datetime.strptime(v_date.get().strip(), "%d/%m/%Y")
        except ValueError:
            messagebox.showwarning("Date invalide", "Format attendu : jj/mm/aaaa (ex. 13/11/2026)")
            return None

    def _decaler(self, v_periode, v_date, sens, action):
        d = self._lire_date(v_date)
        if d is not None:
            v_date.set(decaler_date(v_periode.get(), d, sens).strftime("%d/%m/%Y"))
            action()

    @staticmethod
    def _station_choisie(v_station):
        return None if v_station.get() == "Toutes" else int(v_station.get())

    def _onglet_historique(self):
        page = tk.Frame(self.onglets, bg=COULEUR_FOND)
        self.onglets.add(page, text="Historique")
        barre, self.h_periode, self.h_date, self.h_station = self._barre_periode(page, self.afficher_historique)
        self.h_capteur = tk.StringVar(value="Température")
        tk.Label(barre, text="   Capteur :", bg=COULEUR_FOND, font=POLICE_TEXTE).pack(side="left")
        cb = ttk.Combobox(barre, textvariable=self.h_capteur, state="readonly", width=12,
                          values=["Température", "Vent", "Pluie", "Direction"])
        cb.pack(side="left", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda e: self.afficher_historique())

        self.fig_h = Figure(figsize=(10, 6), dpi=90)
        self.ax_h = self.fig_h.add_subplot(1, 1, 1)
        self.canvas_h = FigureCanvasTkAgg(self.fig_h, master=page)
        self.canvas_h.get_tk_widget().pack(fill="both", expand=True)

    # -- onglet 4 -----------------------------------------------------------
    def _onglet_statistiques(self):
        page = tk.Frame(self.onglets, bg=COULEUR_FOND)
        self.onglets.add(page, text="Statistiques")
        _, self.s_periode, self.s_date, self.s_station = self._barre_periode(page, self.afficher_statistiques)
        self.arbre_stats = ttk.Treeview(page, columns=("grandeur", "valeur"), show="headings", height=20)
        self.arbre_stats.heading("grandeur", text="Grandeur")
        self.arbre_stats.heading("valeur", text="Valeur")
        self.arbre_stats.column("grandeur", width=380)
        self.arbre_stats.column("valeur", width=300)
        self.arbre_stats.pack(fill="both", expand=True, padx=6, pady=6)

    # -- onglet 5 -----------------------------------------------------------
    def _onglet_reglages(self):
        page = tk.Frame(self.onglets, bg=COULEUR_FOND)
        self.onglets.add(page, text="Réglages")
        c = self._carte(page, "Seuils d'alarme")
        c.pack(anchor="nw", padx=10, pady=10)
        self.reglages = {}
        champs = [("temp_min", "Température basse (°C)", self.station.temp_min),
                  ("temp_max", "Température haute (°C)", self.station.temp_max),
                  ("pluie_min", "Pluie : contenu bas (ml)", self.station.pluie_min),
                  ("pluie_max", "Pluie : contenu haut (ml)", self.station.pluie_max),
                  ("seuil_pic", "Seuil de détection des pics de vent (km/h)", self.station.seuil_pic)]
        for i, (cle, texte, val) in enumerate(champs):
            ttk.Label(c, text=texte, style="Carte.TLabel").grid(row=i, column=0, sticky="w", pady=3)
            v = tk.StringVar(value=f"{val:g}")
            ttk.Spinbox(c, textvariable=v, from_=-50, to=1000, increment=0.5, width=8).grid(row=i, column=1, padx=8)
            self.reglages[cle] = v
        ttk.Button(c, text="Appliquer", command=self.click_appliquer).grid(row=len(champs), column=0, pady=10, sticky="w")

        c2 = self._carte(page, "Informations")
        c2.pack(anchor="nw", padx=10, pady=10, fill="x")
        lo_hi = "\n".join(f"   {s} : {a:g} à {b:g} °C" for s, (a, b) in config.LIMITES_SAISON.items())
        texte = (f"Source : {self.acquisition.description()}\n"
                 f"Fichiers de données : {self.stockage.dossier}\n"
                 f"Enregistrement : une moyenne toutes les {config.PERIODE_ENREGISTREMENT_S} s, pics immédiatement\n"
                 f"Pluviomètre : {config.ML_PAR_BASCULE:g} ml par basculement\n"
                 f"Anémomètre : {config.KMH_PAR_IMPULSION_SECONDE:g} km/h par impulsion/s\n"
                 f"Limites de saison (temps hors limite) :\n{lo_hi}\n"
                 "Les conversions et limites se modifient dans config.py.")
        ttk.Label(c2, text=texte, style="Carte.TLabel", justify="left").pack(anchor="w")

    # ======================================================================= boucle IHM
    def rafraichir(self):
        """Appelée toutes les PERIODE_IHM_MS : vide la queue, met à jour l'affichage, se reprogramme."""
        nouvelle = False
        try:
            while True:
                type_msg, contenu = self.file.get_nowait()
                if type_msg == "mesure":
                    self.traiter_mesure(contenu)
                    nouvelle = True
                elif type_msg == "erreur":
                    self._en_erreur = True
                    self.journal(contenu)
                    self.lbl_source.configure(text="Boîtier déconnecté, reconnexion...", fg=COULEUR_ALARME)
                elif type_msg == "info":
                    self._en_erreur = False
                    self.journal(contenu)
                    self.lbl_source.configure(text=self.acquisition.description(), fg="#555")
        except queue.Empty:
            pass
        except Exception as e:           # stabilité : une erreur d'affichage ne doit pas tout arrêter
            self.journal(f"Erreur interne : {e}")

        self.lbl_heure.configure(text=datetime.now().strftime("%d/%m/%Y  %H:%M:%S"))
        if nouvelle:
            self.afficher_valeurs()
            if self.onglets.index("current") == 1:
                self.afficher_temps_reel()
        self.after(config.PERIODE_IHM_MS, self.rafraichir)

    def traiter_mesure(self, mesure):
        """Calculs + enregistrement d'une mesure reçue du thread."""
        for ev in self.station.mettre_a_jour(mesure):
            self.journal(ev)
        if self.station.nouveau_pic is not None:
            t, v = self.station.nouveau_pic
            self.stockage.ajouter_pic(t, v, mesure.station)
        self.stockage.ajouter(mesure, self.station.nouvelles_bascules)
        if self.stockage.erreur:
            self.journal(self.stockage.erreur)

    def afficher_valeurs(self):
        """Met à jour les étiquettes du tableau de bord et de la barre du haut."""
        s = self.station
        self.lbl_numero.configure(text=f"{s.numero}")
        self.leds.afficher(s.bits_station)
        self.lbl_binaire.configure(text="".join("1" if b else "0" for b in s.bits_station))

        self.lbl_temp.configure(text=f"{s.temperature:.1f} °C")
        if s.alarmes["temp_haute"]:
            self.lbl_temp_alarme.configure(text="▲ ALARME : température trop haute", fg="white", bg=COULEUR_ALARME)
        elif s.alarmes["temp_basse"]:
            self.lbl_temp_alarme.configure(text="▼ ALARME : température trop basse", fg="white", bg=COULEUR_ALARME)
        else:
            self.lbl_temp_alarme.configure(text="Température normale", fg=COULEUR_OK, bg=COULEUR_CARTE)
        self.lbl_temp_seuils.configure(text=f"Seuils : {s.temp_min:g} °C / {s.temp_max:g} °C")
        nom, lo, hi = s.saison_courante()
        self.lbl_saison.configure(text=f"Saison : {nom} (limites {lo:g} à {hi:g} °C)"
                                       + ("  -> HORS LIMITE" if s.hors_saison else ""))
        self.lbl_hors_saison.configure(text=f"Temps hors limite de saison : {s.texte_temps_hors_saison()}")

        self.lbl_vent.configure(text=f"{s.vent_kmh:.1f} km/h")
        dernier = f", dernier pic {s.pics[-1][1]:.1f} km/h à {s.pics[-1][0]:%H:%M:%S}" if s.pics else ""
        self.lbl_vent_max.configure(text=f"Maximum depuis le lancement : {s.vent_max_kmh:.1f} km/h{dernier}")
        self.lbl_direction.configure(text=f"Direction : {direction_texte_long(s.direction_deg)} ({s.direction_txt})")
        self.lbl_direction_deg.configure(text=f"{s.direction_deg:.0f}°")
        self.boussole.afficher(s.direction_deg)

        self.lbl_pluie.configure(text=f"{s.volume_ml:.1f} ml")
        self.lbl_bascules.configure(text=f"Compteur : {s.bascules_contenant} basculement(s)")
        if s.alarmes["pluie_haute"]:
            self.lbl_pluie_alarme.configure(text="▲ ALARME : contenant plein", fg="white", bg=COULEUR_ALARME)
        elif s.alarmes["pluie_basse"]:
            self.lbl_pluie_alarme.configure(text="▼ ALARME : pluie insuffisante", fg="white", bg=COULEUR_ALARME)
        else:
            self.lbl_pluie_alarme.configure(text="Niveau normal", fg=COULEUR_OK, bg=COULEUR_CARTE)
        self.lbl_pluie_seuils.configure(text=f"Seuils : {s.pluie_min:g} ml / {s.pluie_max:g} ml")

    def afficher_temps_reel(self):
        """Redessine les 4 courbes temps réel à partir de l'historique de Station."""
        s = self.station
        if not s.h_temps:
            return
        x = list(s.h_temps)
        self.l_temp.set_data(x, list(s.h_temperature))
        self.l_tmax.set_ydata([s.temp_max, s.temp_max])
        self.l_tmin.set_ydata([s.temp_min, s.temp_min])
        self.l_vent.set_data(x, list(s.h_vent))
        pics = [p for p in s.pics if p[0] >= x[0]]
        self.l_pics.set_data([p[0] for p in pics], [p[1] for p in pics])
        if pics:
            t_max, v_max = max(pics, key=lambda p: p[1])
            self.txt_pic.set_text(f"Pic max affiché : {v_max:.1f} km/h à {t_max:%H:%M:%S}")
        else:
            self.txt_pic.set_text("")
        self.l_dir.set_data(x, list(s.h_direction))
        self.l_pluie.set_data(x, list(s.h_pluie_ml))
        self.l_pmax.set_ydata([s.pluie_max, s.pluie_max])
        self.l_pmin.set_ydata([s.pluie_min, s.pluie_min])

        ax_t, ax_v, ax_d, ax_p = self.ax_tr
        fin = x[-1] if len(x) > 1 else x[0].replace(microsecond=0)
        for ax in self.ax_tr:
            ax.set_xlim(x[0], fin if fin > x[0] else None)
        temps = list(s.h_temperature) + [s.temp_min, s.temp_max]
        ax_t.set_ylim(min(temps) - 2, max(temps) + 2)
        ax_v.set_ylim(0, max(max(s.h_vent), s.seuil_pic) * 1.25 + 1)
        ax_p.set_ylim(0, max(max(s.h_pluie_ml), s.pluie_max) * 1.15 + 1)
        self.canvas_tr.draw_idle()

    def afficher_historique(self):
        """Graphe d'évolution du capteur choisi sur la période choisie."""
        d = self._lire_date(self.h_date)
        if d is None:
            return
        periode, capteur = self.h_periode.get(), self.h_capteur.get()
        self._occupe(True)
        try:
            serie = self.statistiques.serie_evolution(capteur, periode, d, self._station_choisie(self.h_station))
        finally:
            self._occupe(False)
        ax = self.ax_h
        ax.clear()
        x = serie["x"]
        if capteur == "Température":
            ax.fill_between(x, serie["min"], serie["max"], color="#ffcc80", alpha=0.6, label="min / max")
            ax.plot(x, serie["moyenne"], color="#e65100", marker=".", label="Moyenne")
            ax.axhline(self.station.temp_max, color=COULEUR_ALARME, ls="--", label="Seuil haut")
            ax.axhline(self.station.temp_min, color="#1565c0", ls="--", label="Seuil bas")
            ax.set_ylabel("°C")
        elif capteur == "Vent":
            ax.plot(x, serie["moyenne"], color="#00838f", marker=".", label="Vent moyen")
            ax.plot(x, serie["max"], "v", color=COULEUR_ALARME, label="Pic maximal")
            ax.set_ylabel("km/h")
        elif capteur == "Pluie":
            largeur = serie["pas"] / 86400 * 0.9
            ax.bar(x, serie["somme"], width=largeur, color="#1565c0", label="Pluie par intervalle")
            ax.set_ylabel("ml")
        elif capteur == "Direction":
            ax.plot(x, serie["points"], ".", color="#6a1b9a", ms=3, label="Direction")
            ax.set_ylim(0, 360); ax.set_yticks([0, 45, 90, 135, 180, 225, 270, 315, 360])
            ax.set_yticklabels(["N", "NE", "E", "SE", "S", "SO", "O", "NO", "N"])
        ax.set_xlim(serie["debut"], serie["fin"])
        if periode == "Semaine":
            ax.xaxis.set_major_locator(mdates.DayLocator())
        elif periode == "An":
            ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_major_formatter(formateur_date(periode))
        debut, fin = bornes_periode(periode, d)
        titre = {"Jour": f"{debut:%d/%m/%Y}", "Semaine": f"semaine du {debut:%d/%m/%Y}",
                 "Mois": f"{debut:%m/%Y}", "An": f"{debut:%Y}"}[periode]
        ax.set_title(f"{capteur} : {titre}")
        ax.grid(alpha=0.3)
        ax.legend(loc="upper left", fontsize=9)
        self.fig_h.autofmt_xdate()
        self.canvas_h.draw_idle()

    def afficher_statistiques(self):
        """Remplit le tableau de statistiques de la période choisie."""
        d = self._lire_date(self.s_date)
        if d is None:
            return
        self.stockage.vider_tampon()      # pour inclure les dernières secondes
        self._occupe(True)
        try:
            res = self.statistiques.calculer(self.s_periode.get(), d, self._station_choisie(self.s_station))
        finally:
            self._occupe(False)
        self.arbre_stats.delete(*self.arbre_stats.get_children())
        for cle, val in res.items():
            texte = f"{val:.2f}" if isinstance(val, float) else str(val)
            self.arbre_stats.insert("", "end", values=(cle, texte))

    def _occupe(self, actif):
        """Curseur d'attente pendant les relectures longues (une année = plusieurs secondes)."""
        self.configure(cursor="watch" if actif else "")
        self.update_idletasks()

    def _changement_onglet(self, _evt):
        i = self.onglets.index("current")
        if i == 1:
            self.afficher_temps_reel()
        elif i == 2:
            self.stockage.vider_tampon()
            self.afficher_historique()
        elif i == 3:
            self.afficher_statistiques()

    # ======================================================================= actions
    def journal(self, texte):
        """Ajoute une ligne horodatée en haut du journal (500 lignes au plus)."""
        self.liste_journal.insert(0, f"{datetime.now():%H:%M:%S}  {texte}")
        if "ALARME" in texte.upper() or "haute" in texte or "basse" in texte or "plein" in texte \
                or "insuffisante" in texte or "Erreur" in texte or "interrompue" in texte:
            self.liste_journal.itemconfigure(0, fg=COULEUR_ALARME)
        elif texte.startswith("Pic"):
            self.liste_journal.itemconfigure(0, fg="#00838f")
        if self.liste_journal.size() > 500:
            self.liste_journal.delete(500, "end")

    def click_vider(self):
        self.station.vider_pluviometre()
        self.journal("Pluviomètre vidé (contenu remis à zéro)")
        if self.station.temperature is not None:
            self.station.verifier_alarmes()
            self.afficher_valeurs()

    def click_appliquer(self):
        try:
            v = {k: float(var.get().replace(",", ".")) for k, var in self.reglages.items()}
            self.station.regler_seuils(**v)
        except ValueError as e:
            messagebox.showerror("Réglage invalide", str(e) if "seuil" in str(e) else "Valeurs numériques attendues")
            return
        self.journal("Seuils modifiés")
        if self.station.temperature is not None:
            self.afficher_valeurs()
            self.afficher_temps_reel()

    def quitter(self):
        """Arrêt propre : thread, tâches DAQ, données en attente, fenêtre."""
        self.thread.arreter()
        self.thread.join(timeout=3)
        self.stockage.fermer()
        self.destroy()
