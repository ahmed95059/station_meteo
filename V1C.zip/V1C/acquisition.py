"""
acquisition.py : lecture des capteurs de la station météo.

Script NON exécutable seul (importé par main.py et ihm.py).
Imports : time, math, random, threading, datetime, dataclasses, config,
          nidaqmx (importé uniquement si l'acquisition réelle est demandée).

Contenu :
- Mesure             : une mesure complète de tous les capteurs à un instant donné.
- AcquisitionDAQ     : lecture du vrai boîtier NI USB-6009 / USB-6001 via nidaqmx.
- AcquisitionSimulee : mêmes méthodes, mais valeurs générées (tests hors salle).
- ThreadAcquisition  : boucle cadencée qui lit l'acquisition et pousse les mesures dans une queue.

Les deux classes d'acquisition exposent exactement la même interface :
ouvrir(), scruter_pluviometre(), lire_temperature(), lire_girouette(), lire_anemometre(),
lire_pluviometre(), lire_numero_station(), fermer().
L'IHM ne sait donc pas si elle est branchée sur le matériel ou sur la simulation.
"""

import math
import random
import threading
import time
from dataclasses import dataclass
from datetime import datetime

import config


# ---------------------------------------------------------------------------
@dataclass
class Mesure:
    """Une mesure complète de la station à un instant donné."""
    horodatage: datetime    # date et heure de la mesure
    station: int            # numéro de station lu sur le codeur 4 bits (0 à 15)
    temperature: float      # °C
    direction_deg: float    # direction d'où vient le vent, 0° = Nord, 90° = Est
    vent_kmh: float         # vitesse moyenne du vent sur la dernière période
    bascules: int           # nombre cumulé de basculements du pluviomètre depuis ouvrir()


# ---------------------------------------------------------------------------
def tension_vers_temperature(u):
    """Convertit la tension du capteur de température (V) en °C (loi linéaire de config)."""
    return config.TEMPERATURE_A * u + config.TEMPERATURE_B


def tension_vers_direction(u):
    """Convertit la tension de la girouette (V) en degrés, ramenés dans [0, 360[."""
    deg = u / config.GIROUETTE_U_MAX * 360.0 + config.GIROUETTE_DECALAGE_DEG
    return deg % 360.0


def bits_vers_entier(bits):
    """Convertit une liste de booléens [bit0, bit1, bit2, bit3] en entier."""
    n = 0
    for i, b in enumerate(bits):
        if b:
            n |= 1 << i
    return n


# ---------------------------------------------------------------------------
class AcquisitionDAQ:
    """Acquisition réelle avec le boîtier NI (librairie nidaqmx)."""

    def __init__(self, nom_device=config.NOM_DEVICE):
        self.nom_device = nom_device    # str : nom du boîtier (ex. "Dev1"), "" = auto
        self.task_ai = None             # nidaqmx.Task : girouette + température
        self.task_anemo = None          # nidaqmx.Task : compteur CTR0
        self.task_pluvio = None         # nidaqmx.Task : ligne P0.7
        self.task_station = None        # nidaqmx.Task : port P1, lignes 0 à 3
        self.bascules = 0               # int : basculements comptés depuis ouvrir()
        self._etat_pluvio = None        # bool : dernier niveau lu sur P0.7
        self._t_derniere_bascule = 0.0  # float : instant (s) du dernier basculement (anti-rebond)
        self._t_lecture_anemo = 0.0     # float : instant (s) de la dernière lecture du compteur
        self._derniere_ai = (0.0, 0.0)  # tuple : dernières tensions (girouette, température)

    # -- recherche du boîtier, comme dans le cours (exercice Error) --
    def trouver_device(self):
        """Retourne le nom du premier boîtier USB-600x trouvé ; lève DaqError sinon."""
        import nidaqmx
        import nidaqmx.system
        if self.nom_device:
            return self.nom_device
        for device in nidaqmx.system.System.local().devices:
            if device.product_type.find("USB-600") != -1:
                return device.name
        raise nidaqmx.DaqError("Aucun boîtier USB-600x trouvé", -200220)

    def ouvrir(self):
        """Crée et configure les 4 tâches nidaqmx. Lève une exception si le boîtier est absent."""
        import nidaqmx
        from nidaqmx.constants import Edge, LineGrouping, TerminalConfiguration

        self.fermer()
        dev = self.trouver_device()
        self.nom_device = dev

        # Voies analogiques : girouette (AI3) puis température (AI6), en RSE comme dans le cours.
        self.task_ai = nidaqmx.Task()
        self.task_ai.ai_channels.add_ai_voltage_chan(
            physical_channel=f"{dev}/{config.VOIE_GIROUETTE},{dev}/{config.VOIE_TEMPERATURE}",
            terminal_config=TerminalConfiguration.RSE)

        # Anémomètre : comptage des fronts descendants sur PFI0 par CTR0.
        self.task_anemo = nidaqmx.Task()
        voie = self.task_anemo.ci_channels.add_ci_count_edges_chan(
            counter=f"{dev}/{config.COMPTEUR_ANEMOMETRE}", edge=Edge.FALLING)
        voie.ci_count_edges_term = f"/{dev}/{config.TERMINAL_ANEMOMETRE}"
        self.task_anemo.start()
        self._t_lecture_anemo = time.monotonic()

        # Pluviomètre : une ligne numérique scrutée régulièrement.
        self.task_pluvio = nidaqmx.Task()
        self.task_pluvio.di_channels.add_di_chan(
            lines=f"{dev}/{config.LIGNE_PLUVIOMETRE}", line_grouping=LineGrouping.CHAN_PER_LINE)

        # Numéro de station : 4 bits séparés sur P1.
        self.task_station = nidaqmx.Task()
        self.task_station.di_channels.add_di_chan(
            lines=f"{dev}/{config.LIGNES_NUMERO_STATION}", line_grouping=LineGrouping.CHAN_PER_LINE)

        self.bascules = 0
        self._etat_pluvio = bool(self.task_pluvio.read())

    def scruter_pluviometre(self):
        """Lit P0.7 et compte un basculement à chaque passage au niveau actif (avec anti-rebond).
        À appeler souvent (toutes les 20 ms) car les impulsions ne sont pas mémorisées par le boîtier."""
        etat = bool(self.task_pluvio.read())
        maintenant = time.monotonic()
        if etat != self._etat_pluvio and etat == config.NIVEAU_ACTIF_PLUVIOMETRE:
            if maintenant - self._t_derniere_bascule >= config.ANTI_REBOND_PLUVIO_S:
                self.bascules += 1
                self._t_derniere_bascule = maintenant
        self._etat_pluvio = etat

    def _lire_ai(self):
        """Lit les deux voies analogiques en une seule fois et mémorise le résultat."""
        data = self.task_ai.read()
        self._derniere_ai = (float(data[0]), float(data[1]))
        return self._derniere_ai

    def lire_girouette(self):
        """Retourne la direction du vent en degrés (lit AI3 et AI6)."""
        u_gir, _ = self._lire_ai()
        return tension_vers_direction(u_gir)

    def lire_temperature(self):
        """Retourne la température en °C (utilise la tension lue par lire_girouette)."""
        return tension_vers_temperature(self._derniere_ai[1])

    def lire_anemometre(self):
        """Lit le compteur, le remet à zéro et retourne la vitesse du vent en km/h."""
        impulsions = int(self.task_anemo.read())
        self.task_anemo.stop()
        self.task_anemo.start()
        maintenant = time.monotonic()
        duree = max(maintenant - self._t_lecture_anemo, 1e-3)
        self._t_lecture_anemo = maintenant
        return impulsions / duree * config.KMH_PAR_IMPULSION_SECONDE

    def lire_pluviometre(self):
        """Retourne le nombre cumulé de basculements depuis ouvrir()."""
        return self.bascules

    def lire_numero_station(self):
        """Retourne le numéro de station (0 à 15) lu sur le codeur 4 bits du port P1."""
        bits = self.task_station.read()
        if not isinstance(bits, list):
            bits = [bits]
        n = bits_vers_entier(bits)
        if config.INVERSER_NUMERO_STATION:
            n = (~n) & 0x0F
        return n

    def fermer(self):
        """Ferme proprement toutes les tâches ouvertes (sans lever d'erreur)."""
        for nom in ("task_ai", "task_anemo", "task_pluvio", "task_station"):
            task = getattr(self, nom)
            if task is not None:
                try:
                    task.close()
                except Exception:
                    pass
                setattr(self, nom, None)

    def description(self):
        return f"Boîtier NI {self.nom_device}"


# ---------------------------------------------------------------------------
class AcquisitionSimulee:
    """Acquisition simulée : génère des valeurs réalistes, même interface que AcquisitionDAQ."""

    def __init__(self, numero_station=config.NUMERO_STATION_SIMULEE, graine=None):
        self.numero_station = numero_station   # int : numéro renvoyé par lire_numero_station()
        self.bascules = 0                      # int : basculements cumulés
        self._rng = random.Random(graine)      # random.Random : générateur pseudo-aléatoire
        self._direction = self._rng.uniform(0, 360)  # float : direction courante (marche aléatoire)
        self._vent = 8.0                       # float : vent de base (km/h)
        self._t0 = time.monotonic()            # float : instant d'ouverture
        self._prochaine_bascule = 0.0          # float : instant du prochain basculement simulé

    def ouvrir(self):
        self.bascules = 0
        self._t0 = time.monotonic()
        self._prochaine_bascule = self._t0 + self._rng.uniform(5, 20)

    def scruter_pluviometre(self):
        """Simule une averse : un basculement toutes les 5 à 20 s."""
        maintenant = time.monotonic()
        if maintenant >= self._prochaine_bascule:
            self.bascules += 1
            self._prochaine_bascule = maintenant + self._rng.uniform(5, 20)

    def lire_temperature(self):
        """Température : cycle journalier (min à 5 h, max à 15 h) + oscillation lente + bruit."""
        h = datetime.now().hour + datetime.now().minute / 60
        t = 12 + 8 * math.sin((h - 9) / 24 * 2 * math.pi)
        t += 3 * math.sin((time.monotonic() - self._t0) / 120)   # varie en quelques minutes pour la démo
        return t + self._rng.gauss(0, 0.2)

    def lire_girouette(self):
        """Direction : marche aléatoire autour de la valeur précédente."""
        self._direction = (self._direction + self._rng.gauss(0, 8)) % 360
        return self._direction

    def lire_anemometre(self):
        """Vent : base lentement variable + bruit + rafales occasionnelles (pour voir des pics)."""
        self._vent = min(max(self._vent + self._rng.gauss(0, 0.5), 2), 25)
        v = self._vent + self._rng.gauss(0, 1.0)
        if self._rng.random() < 0.05:
            v += self._rng.uniform(5, 15)
        # le vrai capteur donne un nombre entier d'impulsions par seconde
        impulsions = max(0, round(v / config.KMH_PAR_IMPULSION_SECONDE))
        return impulsions * config.KMH_PAR_IMPULSION_SECONDE

    def lire_pluviometre(self):
        return self.bascules

    def lire_numero_station(self):
        return self.numero_station

    def fermer(self):
        pass

    def description(self):
        return "Simulation (aucun boîtier)"


# ---------------------------------------------------------------------------
def creer_acquisition(mode="auto"):
    """Crée l'acquisition demandée.
    Entrée  : mode -> str ("daq", "simu" ou "auto")
    Sortie  : (acquisition, message) -> (AcquisitionDAQ | AcquisitionSimulee, str)
    En mode "auto", essaie le boîtier et bascule sur la simulation s'il est absent."""
    if mode == "simu":
        acq = AcquisitionSimulee()
        acq.ouvrir()
        return acq, "Mode simulation"
    try:
        acq = AcquisitionDAQ()
        acq.ouvrir()
        return acq, f"Boîtier trouvé : {acq.nom_device}"
    except Exception as e:     # nidaqmx absent, pilote absent ou boîtier débranché
        if mode == "daq":
            raise
        acq = AcquisitionSimulee()
        acq.ouvrir()
        return acq, f"Boîtier indisponible ({e.__class__.__name__}) : passage en simulation"


# ---------------------------------------------------------------------------
class ThreadAcquisition(threading.Thread):
    """Thread qui lit les capteurs à cadence fixe et dépose les résultats dans une queue.

    Messages déposés dans la queue :
    ("mesure", Mesure)  à chaque période d'acquisition,
    ("erreur", str)     si le boîtier ne répond plus (le thread retente ensuite d'ouvrir).
    """

    def __init__(self, acquisition, file_sortie):
        super().__init__(daemon=True, name="Acquisition")
        self.acquisition = acquisition   # AcquisitionDAQ | AcquisitionSimulee
        self.file = file_sortie          # queue.Queue : messages vers l'IHM
        self._arret = threading.Event()  # threading.Event : demande d'arrêt

    def arreter(self):
        """Demande l'arrêt du thread (il s'arrête à la fin de la période en cours)."""
        self._arret.set()

    def run(self):
        prochaine = time.monotonic() + config.PERIODE_ACQUISITION_S
        en_erreur = False
        while not self._arret.is_set():
            try:
                if en_erreur:
                    self.acquisition.ouvrir()
                    en_erreur = False
                    self.file.put(("info", "Boîtier reconnecté"))
                    prochaine = time.monotonic() + config.PERIODE_ACQUISITION_S

                # Scrutation rapide du pluviomètre jusqu'à la fin de la période.
                while time.monotonic() < prochaine and not self._arret.is_set():
                    self.acquisition.scruter_pluviometre()
                    time.sleep(config.PERIODE_SCRUTATION_S)
                prochaine += config.PERIODE_ACQUISITION_S

                direction = self.acquisition.lire_girouette()   # lit aussi la tension de température
                mesure = Mesure(
                    horodatage=datetime.now(),
                    station=self.acquisition.lire_numero_station(),
                    temperature=self.acquisition.lire_temperature(),
                    direction_deg=direction,
                    vent_kmh=self.acquisition.lire_anemometre(),
                    bascules=self.acquisition.lire_pluviometre(),
                )
                self.file.put(("mesure", mesure))
            except Exception as e:     # stabilité : on ne laisse jamais le thread mourir
                if not en_erreur:
                    self.file.put(("erreur", f"Acquisition interrompue : {e}"))
                en_erreur = True
                self.acquisition.fermer()
                self._arret.wait(config.DELAI_RECONNEXION_S)
        self.acquisition.fermer()
