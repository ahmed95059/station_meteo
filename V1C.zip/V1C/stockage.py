"""
stockage.py : enregistrement et relecture des mesures dans des fichiers CSV.

Script NON exécutable seul (importé par ihm.py, stats.py et main.py).
Imports : csv, os, math, random, datetime, numpy, config.

Format : un fichier par jour, donnees/AAAA-MM-JJ.csv, séparateur « ; », colonnes :
    horodatage ; station ; capteur ; valeur
capteur vaut : temperature (°C), direction (°), vent (km/h), vent_pic (km/h),
               pluie_ml (ml tombés pendant l'intervalle), station (numéro, écrit à chaque changement).

Pour ne pas produire des fichiers énormes, les mesures (1 par seconde) sont moyennées et
écrites toutes les PERIODE_ENREGISTREMENT_S secondes. Les pics sont écrits immédiatement.
"""

import csv
import math
import os
import random
from datetime import datetime, timedelta

import numpy as np

import config

ENTETE = ["horodatage", "station", "capteur", "valeur"]
FORMAT_DATE = "%Y-%m-%d %H:%M:%S"


def moyenne_angles(angles_deg):
    """Moyenne vectorielle de directions (évite que la moyenne de 350° et 10° donne 180°)."""
    s = sum(math.sin(math.radians(a)) for a in angles_deg)
    c = sum(math.cos(math.radians(a)) for a in angles_deg)
    return math.degrees(math.atan2(s, c)) % 360


class Stockage:
    """Écrit les mesures moyennées dans les CSV journaliers et les relit pour les graphes et stats."""

    def __init__(self, dossier=None):
        base = os.path.dirname(os.path.abspath(__file__))
        self.dossier = dossier or os.path.join(base, config.DOSSIER_DONNEES)  # str
        os.makedirs(self.dossier, exist_ok=True)
        self._debut_bloc = None       # datetime : début de l'intervalle en cours de moyennage
        self._temperatures = []       # list[float]
        self._directions = []         # list[float]
        self._vents = []              # list[float]
        self._bascules = 0            # int : basculements pendant l'intervalle
        self._station = None          # int : station de l'intervalle en cours
        self._derniere_station = None # int : dernière station écrite (pour la ligne « station »)
        self.erreur = None            # str : dernière erreur d'écriture (None si tout va bien)

    # ------------------------------------------------------------------ écriture
    def chemin_jour(self, jour):
        """Chemin du fichier CSV du jour (date ou datetime)."""
        return os.path.join(self.dossier, f"{jour:%Y-%m-%d}.csv")

    def ecrire_lignes(self, lignes):
        """Ajoute des lignes [datetime, station, capteur, valeur] dans le(s) fichier(s) du jour.
        Ne lève pas d'exception : en cas d'erreur, le message est rangé dans self.erreur."""
        par_jour = {}
        for ligne in lignes:
            par_jour.setdefault(ligne[0].date(), []).append(ligne)
        try:
            for jour, contenu in par_jour.items():
                chemin = self.chemin_jour(jour)
                nouveau = not os.path.exists(chemin)
                with open(chemin, "a", newline="", encoding="utf-8") as f:
                    w = csv.writer(f, delimiter=";")
                    if nouveau:
                        w.writerow(ENTETE)
                    for t, station, capteur, valeur in contenu:
                        w.writerow([t.strftime(FORMAT_DATE), station, capteur, f"{valeur:.3f}"])
            self.erreur = None
        except OSError as e:
            self.erreur = f"Erreur d'écriture CSV : {e}"

    def ajouter(self, mesure, nouvelles_bascules):
        """Accumule une mesure ; écrit une ligne moyennée par capteur à la fin de chaque intervalle.
        Entrées : mesure -> acquisition.Mesure, nouvelles_bascules -> int."""
        if self._station is not None and mesure.station != self._station:
            self.vider_tampon()          # changement de station : on clôt l'intervalle en cours
        if self._debut_bloc is None:
            self._debut_bloc = mesure.horodatage
        self._station = mesure.station
        self._temperatures.append(mesure.temperature)
        self._directions.append(mesure.direction_deg)
        self._vents.append(mesure.vent_kmh)
        self._bascules += nouvelles_bascules
        if (mesure.horodatage - self._debut_bloc).total_seconds() >= config.PERIODE_ENREGISTREMENT_S:
            self.vider_tampon()

    def ajouter_pic(self, horodatage, vitesse, station):
        """Enregistre immédiatement un pic de vent."""
        self.ecrire_lignes([[horodatage, station, "vent_pic", vitesse]])

    def vider_tampon(self):
        """Écrit les moyennes de l'intervalle en cours (appelé aussi à la fermeture)."""
        if not self._temperatures:
            return
        t = self._debut_bloc
        st = self._station
        lignes = []
        if st != self._derniere_station:
            lignes.append([t, st, "station", st])
            self._derniere_station = st
        lignes += [
            [t, st, "temperature", sum(self._temperatures) / len(self._temperatures)],
            [t, st, "direction", moyenne_angles(self._directions)],
            [t, st, "vent", sum(self._vents) / len(self._vents)],
            [t, st, "pluie_ml", self._bascules * config.ML_PAR_BASCULE],
        ]
        self.ecrire_lignes(lignes)
        self._debut_bloc = None
        self._temperatures, self._directions, self._vents = [], [], []
        self._bascules = 0

    def fermer(self):
        self.vider_tampon()

    # ------------------------------------------------------------------ lecture
    def lire(self, debut, fin, station=None):
        """Relit les mesures entre debut (inclus) et fin (exclu).
        Entrées : debut -> datetime, fin -> datetime, station -> int ou None (toutes)
        Sortie  : dict capteur -> (temps, valeurs) avec temps -> np.ndarray de timestamps (s)
                  et valeurs -> np.ndarray de float."""
        brut = {}
        jour = debut.date()
        while jour <= (fin - timedelta(microseconds=1)).date():
            chemin = self.chemin_jour(jour)
            if os.path.exists(chemin):
                try:
                    with open(chemin, newline="", encoding="utf-8") as f:
                        lecteur = csv.reader(f, delimiter=";")
                        next(lecteur, None)                      # en-tête
                        for ligne in lecteur:
                            try:
                                horodatage, st, capteur, valeur = ligne
                                if station is not None and int(st) != station:
                                    continue
                                t = datetime.fromisoformat(horodatage)   # plus rapide que strptime
                                if not (debut <= t < fin):
                                    continue
                                serie = brut.setdefault(capteur, ([], []))
                                serie[0].append(t.timestamp())
                                serie[1].append(float(valeur))
                            except (ValueError, TypeError):
                                continue      # ligne abîmée : on l'ignore
                except OSError:
                    pass
            jour += timedelta(days=1)
        return {k: (np.array(t), np.array(v)) for k, (t, v) in brut.items()}

    def stations_disponibles(self):
        """Liste triée des numéros de station présents dans les fichiers (lecture rapide des 31 derniers fichiers)."""
        stations = set()
        fichiers = sorted(f for f in os.listdir(self.dossier) if f.endswith(".csv"))[-31:]
        for nom in fichiers:
            try:
                with open(os.path.join(self.dossier, nom), newline="", encoding="utf-8") as f:
                    for ligne in csv.DictReader(f, delimiter=";"):
                        if ligne.get("capteur") == "station":
                            stations.add(int(float(ligne["station"])))
            except (OSError, ValueError):
                continue
        return sorted(stations)


# ---------------------------------------------------------------------------
def generer_historique_demo(stockage, jours=400, station=config.NUMERO_STATION_SIMULEE, pas_min=10):
    """Remplit le dossier de données avec un historique fictif (une ligne par capteur toutes les
    pas_min minutes sur les `jours` derniers jours), pour tester les graphes jour/semaine/mois/an
    et les statistiques sans attendre un an. Les fichiers déjà présents ne sont pas modifiés."""
    rng = random.Random(1)
    fin = datetime.now().replace(second=0, microsecond=0)
    t = fin - timedelta(days=jours)
    direction = 225.0
    lignes = []
    pluie_en_cours = 0
    jour_courant = None
    ignorer_jour = False
    while t < fin:
        if t.date() != jour_courant:
            if lignes:
                stockage.ecrire_lignes(lignes)
                lignes = []
            jour_courant = t.date()
            ignorer_jour = os.path.exists(stockage.chemin_jour(jour_courant))
            if not ignorer_jour:
                lignes.append([t, station, "station", station])
        if not ignorer_jour:
            jour_an = t.timetuple().tm_yday
            saisonnier = 11 - 8 * math.cos((jour_an - 15) / 365 * 2 * math.pi)
            journalier = 5 * math.sin((t.hour + t.minute / 60 - 9) / 24 * 2 * math.pi)
            temp = saisonnier + journalier + rng.gauss(0, 1)
            direction = (direction + rng.gauss(0, 10)) % 360
            vent = max(0.0, 12 + 6 * math.sin(jour_an / 7) + rng.gauss(0, 4))
            if pluie_en_cours <= 0 and rng.random() < 0.01:
                pluie_en_cours = rng.randint(3, 30)        # averse de 30 min à 5 h
            pluie = 0.0
            if pluie_en_cours > 0:
                pluie = rng.randint(0, 4) * config.ML_PAR_BASCULE
                pluie_en_cours -= 1
            lignes += [[t, station, "temperature", temp], [t, station, "direction", direction],
                       [t, station, "vent", vent], [t, station, "pluie_ml", pluie]]
            if vent > 22:
                lignes.append([t, station, "vent_pic", vent + rng.uniform(2, 10)])
        t += timedelta(minutes=pas_min)
    if lignes:
        stockage.ecrire_lignes(lignes)
